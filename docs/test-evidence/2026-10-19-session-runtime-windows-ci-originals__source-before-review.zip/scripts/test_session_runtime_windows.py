"""Offline contracts for the one Windows CI attempt. No external requests or .NET execution."""
import base64
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import yaml


ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("runtime_windows", ROOT / "scripts/verify-session-runtime-windows.py")
ci = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ci)
policy = ci.load_policy(ROOT)


class WindowsCiTests(unittest.TestCase):
    def test_workflow_is_one_public_readonly_bounded_push(self):
        path = ROOT / ".github/workflows/windows-session-runtime.yml"
        workflow = yaml.load(path.read_text(), Loader=yaml.BaseLoader)
        self.assertEqual({"push": {"branches": [ci.BRANCH.removeprefix("refs/heads/")],
                                   "paths": [path.relative_to(ROOT).as_posix()]}}, workflow["on"])
        self.assertEqual({"contents": "read"}, workflow["permissions"])
        self.assertEqual(1, len(workflow["jobs"]))
        job = workflow["jobs"]["signature-then-managed"]
        self.assertEqual("windows-2022", job["runs-on"])
        self.assertEqual("15", job["timeout-minutes"])
        self.assertIn("github.event.repository.private == false", job["if"])
        self.assertIn("github.run_attempt == '1'", job["if"])
        checkout, execute = job["steps"]
        self.assertEqual("actions/checkout@d23441a48e516b6c34aea4fa41551a30e30af803", checkout["uses"])
        self.assertEqual("false", checkout["with"]["persist-credentials"])
        self.assertEqual("2", checkout["with"]["fetch-depth"])
        self.assertEqual("powershell", execute["shell"])
        self.assertEqual("14", execute["timeout-minutes"])
        self.assertNotRegex(path.read_text(), "upload-artifact|actions/cache|setup-dotnet|secrets\\.")

    def test_context_rejects_private_and_rerun_before_execution(self):
        with tempfile.TemporaryDirectory() as folder:
            event = Path(folder) / "event.json"
            event.write_text(json.dumps({"repository": {"private": False}}))
            env = {"GITHUB_ACTIONS": "true", "GITHUB_REPOSITORY": ci.REPOSITORY, "GITHUB_REF": ci.BRANCH,
                   "GITHUB_EVENT_NAME": "push", "GITHUB_RUN_ATTEMPT": "1", "RUNNER_OS": "Windows",
                   "GITHUB_SHA": "a" * 40, "GITHUB_EVENT_PATH": str(event)}
            ci.hosted_context(env, "win32")
            for key, value in (("GITHUB_RUN_ATTEMPT", "2"), ("GITHUB_REPOSITORY", "PUBLIC_OTHER/REPO"),
                               ("GITHUB_SHA", "bad"), ("GITHUB_EVENT_NAME", "workflow_dispatch")):
                changed = dict(env, **{key: value})
                with self.subTest(key=key), self.assertRaises(RuntimeError):
                    ci.hosted_context(changed, "win32")
            event.write_text(json.dumps({"repository": {"private": True}}))
            with self.assertRaisesRegex(RuntimeError, "Public repository"):
                ci.hosted_context(env, "win32")

    def test_non_windows_entry_never_executes_or_downloads(self):
        with patch.object(ci.sys, "argv", ["verify-session-runtime-windows.py"]), patch.object(ci.sys, "platform", "linux"), patch.object(ci, "execute") as execute:
            self.assertEqual(2, ci.main())
            execute.assert_not_called()

    def test_exact_parent_and_scope_reject_extra_or_missing_source(self):
        head = "a" * 40
        def runner(parents=None, files=None):
            answers = [head, " ".join(parents or [head, ci.PARENT]), "\n".join(ci.FILES if files is None else files), ""]
            return lambda *_: answers.pop(0)
        self.assertEqual(head, ci.source_gate(runner(), head))
        for run in (runner(parents=[head, "b" * 40]), runner(files=ci.FILES | {"src/PUBLIC_CHANGE.cs"}),
                    runner(files=sorted(ci.FILES)[:-1])):
            with self.assertRaises(RuntimeError):
                ci.source_gate(run, head)

    def test_verifier_must_declare_framework_and_reviewed_version(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "nuget.exe"
            path.write_bytes(b"MZ_PUBLIC_FIXTURE_.NETFramework,Version=v4.7.2")
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), ci.verifier_identity(path))
            path.write_bytes(b"MZ_PUBLIC_FIXTURE_.NETCoreApp,Version=v10.0")
            with self.assertRaises(RuntimeError):
                ci.verifier_identity(path)
        ci.require_verifier_version("NuGet Version: 7.9.0.83\n")
        for output in ("", "NuGet Version: 7.9.0.830", "NuGet Version: 7.8.0.0"):
            with self.subTest(output=output), self.assertRaises(RuntimeError):
                ci.require_verifier_version(output)

    def test_content_archive_license_and_identity_are_independent_gates(self):
        with tempfile.TemporaryDirectory() as folder:
            package = Path(folder) / "PUBLIC.nupkg"
            def write(identity="PUBLIC_RUNTIME", license="MIT", acceptance="false"):
                with zipfile.ZipFile(package, "w") as archive:
                    archive.writestr("PUBLIC.nuspec", f'<package><metadata><id>{identity}</id><version>10.0.13</version><license type="expression">{license}</license><requireLicenseAcceptance>{acceptance}</requireLicenseAcceptance></metadata></package>')
                return base64.b64encode(hashlib.sha512(package.read_bytes()).digest()).decode()
            pin = write()
            ci.package_identity(package, "PUBLIC_RUNTIME", "10.0.13", pin)
            with self.assertRaisesRegex(RuntimeError, "hash"):
                ci.package_identity(package, "PUBLIC_RUNTIME", "10.0.13", "PUBLIC_WRONG_HASH")
            for kwargs in ({"identity": "PUBLIC_WRONG"}, {"license": "PUBLIC_NEW_LICENSE"}, {"acceptance": "true"}):
                pin = write(**kwargs)
                with self.subTest(kwargs=kwargs), self.assertRaisesRegex(RuntimeError, "identity/license"):
                    ci.package_identity(package, "PUBLIC_RUNTIME", "10.0.13", pin)

    def test_nuget_diagnostics_refused_even_when_not_prefixed_warning(self):
        good = "\n".join(("Verifying PUBLIC_RUNTIME.10.0.13", "Content hash: PUBLIC_HASH", "Signature type: Author", "Signature type: Repository"))
        ci.signature_gate(policy, good, "PUBLIC_RUNTIME", "10.0.13", "PUBLIC_HASH")
        for diagnostic in ("NU3018: PUBLIC_UNKNOWN", "INFO: NU3028: PUBLIC_UNKNOWN", "info: offline revocation", "RevocationStatusUnknown", "WARNING: PUBLIC_WARNING"):
            with self.subTest(diagnostic=diagnostic), self.assertRaises(RuntimeError):
                ci.signature_gate(policy, good + "\n" + diagnostic, "PUBLIC_RUNTIME", "10.0.13", "PUBLIC_HASH")

    def test_no_empty_or_skipped_suite_can_be_passed(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "PUBLIC.trx"
            def write(values):
                attributes = " ".join(f'{key}="{value}"' for key, value in values.items())
                path.write_text(f'<TestRun xmlns="http://microsoft.com/schemas/VisualStudio/TeamTest/2010"><ResultSummary><Counters {attributes}/></ResultSummary></TestRun>')
            counters = {"total": 2, "executed": 2, "passed": 2, "failed": 0, "notExecuted": 0}
            write(counters)
            self.assertEqual(counters, ci.trx_counters(path))
            for changed in ({"total": 0, "passed": 0, "executed": 0}, {"notExecuted": 1}, {"failed": 1}, {"executed": 1}):
                write(dict(counters, **changed))
                with self.subTest(changed=changed), self.assertRaises(RuntimeError):
                    ci.trx_counters(path)


if __name__ == "__main__":
    unittest.main()
