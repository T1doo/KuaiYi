from pathlib import Path
import subprocess,json,hashlib,time,datetime,sys,re,xml.etree.ElementTree as E
root=Path.cwd();out=root/'artifacts/cancellation-fixed-signoff';expected='9877e5e3bcc9750bb0faf60ad040e9af7fca07f0';kind=sys.argv[1];assert kind == 'core'
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sources():return {p:sha(root/p) for p in git('ls-files','-z').split('\0') if p and (p.startswith(('src/','tests/','tools/','assets/','scripts/','packaging/')) or p.startswith('Directory.') or p in ('KuaiYi.sln','global.json','NuGet.Config','SPEC.md','AGENTS.md'))}
def dlls():return {str(p.relative_to(root)):sha(p) for d in ('src','tests','tools') for p in (root/d).rglob('*.dll') if '/bin/Release/' in str(p)}
assert git('rev-parse','HEAD')==expected and not git('status','--porcelain=v1');assert not (out/(kind+'-result.json')).exists(),'Exactly one requested run per suite'
before=sources();d_before=dlls();(out/(kind+'-sources-before.json')).write_text(json.dumps(before,indent=2)+'\n');(out/(kind+'-dlls-before.json')).write_text(json.dumps(d_before,indent=2)+'\n')
project='KuaiYi.Core.Tests' if kind=='core' else 'KuaiYi.Codec.Tests';cmd=['python3','-B','scripts/session-sdk.py','test',f'tests/{project}/{project}.csproj','-c','Release','--no-restore','-nodeReuse:false','-p:UseSharedCompilation=false','--logger',f'trx;LogFileName=full-{kind}-fixed-head.trx','--results-directory',str(out)];started=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic();(out/(kind+'-command.json')).write_text(json.dumps(dict(fixedHead=expected,command=cmd,started=started),indent=2)+'\n')
with (out/(kind+'.log')).open('w') as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
after=sources();d_after=dlls();(out/(kind+'-sources-after.json')).write_text(json.dumps(after,indent=2)+'\n');(out/(kind+'-dlls-after.json')).write_text(json.dumps(d_after,indent=2)+'\n');(out/(kind+'-dll-changes.json')).write_text(json.dumps({p:{'before':d_before.get(p),'after':d_after.get(p)} for p in sorted(set(d_before)|set(d_after)) if d_before.get(p)!=d_after.get(p)},indent=2)+'\n')
trx=out/f'full-{kind}-fixed-head.trx';counts=None;failures=[]
if trx.exists():
 ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};tree=E.parse(trx);counts=tree.find('.//t:Counters',ns).attrib;raw=trx.read_text(encoding='utf-8-sig');failures=re.findall(r'<UnitTestResult\b(?=[^>]*outcome="(?:Failed|Error|Aborted|Timeout)")[^>]*>.*?</UnitTestResult>',raw,re.S)
 for i,s in enumerate(failures,1):(out/f'{kind}-failure-{i:03d}.xml').write_text(s+'\n')
result=dict(fixedHead=expected,command=cmd,started=started,seconds=round(time.monotonic()-clock,3),exitCode=code,counts=counts,originalFailureCount=len(failures),sourceCount=len(before),sourcesBeforeAfterEqual=before==after,headStillFixed=git('rev-parse','HEAD')==expected,dirtyAfter=git('status','--porcelain=v1'),trxSha256=sha(trx) if trx.exists() else None,dllBefore=len(d_before),dllAfter=len(d_after),dllChanged=sum(d_before.get(p)!=d_after.get(p) for p in set(d_before)|set(d_after)))
(out/(kind+'-result.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
