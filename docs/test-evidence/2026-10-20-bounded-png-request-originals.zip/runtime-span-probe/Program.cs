using System.Reflection;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Text.Json;
class Probe(byte[] known):MemoryStream
{
    public bool ArrayCalled,SameInput,KnownSlice;
    public override void Write(byte[] buffer,int offset,int count)
    {
        ArrayCalled=true;SameInput=ReferenceEquals(buffer,known);KnownSlice=buffer.AsSpan(offset,count).SequenceEqual(known);
        try{base.Write(buffer,offset,count);}finally{if(!SameInput)CryptographicOperations.ZeroMemory(buffer.AsSpan(offset,count));}
    }
}
class Program
{
    static void Main()
    {
        var assembly=typeof(Stream).Assembly;byte[] known="KUAIYI_SYNTHETIC_SPAN"u8.ToArray();using var probe=new Probe(known);probe.Write(known.AsSpan());
        var opcodes=typeof(OpCodes).GetFields(BindingFlags.Static|BindingFlags.Public).Where(f=>f.FieldType==typeof(OpCode)).Select(f=>(OpCode)f.GetValue(null)!).ToDictionary(c=>unchecked((ushort)c.Value));
        var methods=new[]{typeof(MemoryStream).GetMethod("Write",[typeof(ReadOnlySpan<byte>)])!,typeof(Stream).GetMethod("Write",[typeof(ReadOnlySpan<byte>)])!,typeof(MemoryStream).GetMethod("Write",[typeof(byte[]),typeof(int),typeof(int)])!,typeof(MemoryStream).GetMethod("WriteByte",[typeof(byte)])!};
        var listings=new List<object>();
        foreach(var method in methods)
        {
            byte[] il=method.GetMethodBody()!.GetILAsByteArray()!;var list=new List<object>();int at=0;
            while(at<il.Length)
            {
                int offset=at;ushort code=il[at++];if(code==254)code=(ushort)(65024|il[at++]);var op=opcodes[code];string? call=null;
                if(op.OperandType==OperandType.InlineMethod){var called=method.Module.ResolveMethod(BitConverter.ToInt32(il,at))!;call=called.DeclaringType!.FullName+"."+called;}
                int count=op.OperandType switch{OperandType.InlineNone=>0,OperandType.ShortInlineBrTarget or OperandType.ShortInlineI or OperandType.ShortInlineVar=>1,OperandType.InlineVar=>2,OperandType.InlineI8 or OperandType.InlineR=>8,OperandType.InlineSwitch=>4+4*BitConverter.ToInt32(il,at),_=>4};
                list.Add(new{offset,opcode=op.Name,call});at+=count;
            }
            listings.Add(new{method=method.DeclaringType!.FullName+"."+method,il_sha256=Convert.ToHexStringLower(SHA256.HashData(il)),instructions=list});
        }
        Console.WriteLine(JsonSerializer.Serialize(new{version=assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()!.InformationalVersion,corelib_sha256=Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(assembly.Location))),probe=new{probe.ArrayCalled,probe.SameInput,probe.KnownSlice,output=probe.ToArray().SequenceEqual(known),scope="Only known synthetic slice compared/cleared while callback owns it; no pool tail or returned pool contents read"},listings},new JsonSerializerOptions{WriteIndented=true}));
    }
}
