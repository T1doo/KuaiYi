from pathlib import Path
import subprocess,json,hashlib,time
out=Path('artifacts/capture-finalization-root-cause');dll=Path('tests/KuaiYi.Core.Tests/bin/Release/net10.0/KuaiYi.Core.Tests.dll');before=hashlib.sha256(dll.read_bytes()).hexdigest();command=['python3','-B','scripts/session-sdk.py','test','tests/KuaiYi.Core.Tests/KuaiYi.Core.Tests.csproj','-c','Release','--no-restore','--no-build','-nodeReuse:false','-p:UseSharedCompilation=false','--filter','FullyQualifiedName~HostTerminationTests|FullyQualifiedName~CaptureHostTests','--logger','trx;LogFileName=r04-final-related.trx','--results-directory',str(out)];started=time.time()
with (out/'r04-final-related.log').open('w') as f:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
assert before==hashlib.sha256(dll.read_bytes()).hexdigest()
(out/'r04-command.json').write_text(json.dumps(dict(command=command,exitCode=code,seconds=round(time.time()-started,3),testDllBeforeAndAfterSha256=before),indent=2)+'\n');print('r04',code,flush=True)
