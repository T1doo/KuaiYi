from pathlib import Path
import subprocess,json,time,hashlib
out=Path('artifacts/selection-deadline-root-cause');rows=[]
source_files=['src/KuaiYi.NativeHost/SelectionBrokerClient.cs','tests/KuaiYi.Core.Tests/SelectionBrokerProcessTests.cs'];sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in source_files};(out/'final-check-source-hashes.json').write_text(json.dumps(sources,indent=2)+'\n')
common=['-c','Release','--no-restore','-nodeReuse:false','-p:UseSharedCompilation=false'];checks=[('r04-final-related',['test','tests/KuaiYi.Core.Tests/KuaiYi.Core.Tests.csproj',*common,'--filter','FullyQualifiedName~SelectionBroker|FullyQualifiedName~SelectionBoundaryMarker|FullyQualifiedName~SelectionPhaseTiming|FullyQualifiedName~SelectionProgress|FullyQualifiedName~SelectionSoftBudgetBoundary|FullyQualifiedName~HostTermination|FullyQualifiedName~CaptureHost','--logger','trx;LogFileName=r04-final-related.trx','--results-directory',str(out)]),('r05-app-cross-build',['build','src/KuaiYi.App/KuaiYi.App.csproj',*common,'-p:EnableWindowsTargeting=true'])]
for name,args in checks:
 command=['python3','-B','scripts/session-sdk.py',*args];started=time.monotonic()
 with (out/(name+'.log')).open('w') as f:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
 assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in sources.items())
 rows.append(dict(name=name,command=command,exitCode=code,seconds=round(time.monotonic()-started,3)));(out/'final-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,code,flush=True)
 if code:break
