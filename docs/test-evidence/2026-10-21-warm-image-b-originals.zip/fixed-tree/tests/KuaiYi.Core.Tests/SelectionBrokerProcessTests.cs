using System.Diagnostics;
using KuaiYi.Core;
using KuaiYi.Contracts;
using KuaiYi.NativeHost;
using Xunit;
using Xunit.Abstractions;
using Xunit.Sdk;
using System.Runtime.ExceptionServices;
namespace KuaiYi.Core.Tests;
public sealed class SelectionBrokerProcessTests(ITestOutputHelper output)
{
    private FixtureStarter? finalStarterForTest;private SelectionBrokerClient? finalClientForTest;private Action<FinalBoundaryTrace>? observeFinalBoundaryForTest;private bool useRealFinalDeadlineForTest;
    private sealed record FinalBoundaryTrace(SelectionCaptureStatus Status,bool HookEntered,long FakeMilliseconds,double RealMilliseconds,int Starts,bool StarterEntered,bool StarterReturned,HostExitState? Ownership);
    // Synchronous one-shot test driver: no background timer or concurrent Fire/Dispose.
    private sealed class ControlledDeadline:IDisposable
    {
        private CancellationTokenSource? source;public int Arms{get;private set;}public int Fires{get;private set;}public TimeSpan Due{get;private set;}
        public void Arm(CancellationTokenSource deadline,TimeSpan due){if(Interlocked.CompareExchange(ref source,deadline,null)!=null)throw new InvalidOperationException("Already armed.");Arms++;Due=due;}
        public void Fire(){var held=Interlocked.Exchange(ref source,null)??throw new InvalidOperationException("Not armed.");Fires++;held.Cancel();}
        public void Dispose()=>Interlocked.Exchange(ref source,null);
    }
    private sealed class MonotonicClock:TimeProvider
    {public long Milliseconds=10000;public DateTimeOffset Utc=DateTimeOffset.UtcNow;public override long TimestampFrequency=>1000;public override long GetTimestamp()=>Interlocked.Read(ref Milliseconds);public override DateTimeOffset GetUtcNow()=>Utc;}
    private sealed class ExpiredStarter(MonotonicClock clock,int elapsed):FixtureStarter("normal")
    {public Process? Witness;public override Process Start(ProcessStartInfo info){clock.Milliseconds+=elapsed;var child=base.Start(info);Witness=Process.GetProcessById(child.Id);return child;}}
    [Fact]public async Task PreCancelledSelectionCreatesNoOwnedChild()
    {
        using var cancellation=new CancellationTokenSource();cancellation.Cancel();var starter=new FixtureStarter("normal");await using var client=new SelectionBrokerClient("public-fixture",starter);Assert.Equal(SelectionCaptureStatus.Cancelled,(await client.CaptureAsync(Gesture(),cancellation.Token)).Status);await client.DisposeAsync();Assert.Equal(0,starter.Starts);Assert.Null(starter.Child);Assert.Null(client.ExitState);
    }
    [Theory][InlineData(600)][InlineData(601)]
    public async Task CompletedStartupBeyondAbsoluteBoundaryRejectsBeforeReadingAndRetainsOwnedChildCleanup(int elapsed)
    {
        var clock=new MonotonicClock();var starter=new ExpiredStarter(clock,elapsed);await using var client=new SelectionBrokerClient("public-fixture",starter,clock);Assert.Equal(SelectionCaptureStatus.HardTimeout,(await client.CaptureAsync(Gesture(),default)).Status);using var witness=starter.Witness;Assert.NotNull(witness);await client.DisposeAsync();Assert.Null(client.ExitState);Assert.Equal(1,starter.Starts);Assert.True(witness.HasExited);
    }
    [Theory][InlineData(599,SelectionCaptureStatus.Success)][InlineData(600,SelectionCaptureStatus.HardTimeout)][InlineData(601,SelectionCaptureStatus.HardTimeout)]
    public async Task FinalValidationUsesAbsoluteMonotonicDeadlineWithoutTimerCallback(int elapsed,SelectionCaptureStatus expected)
    {
        using var timer=new ControlledDeadline();using var guard=new CancellationTokenSource(TimeSpan.FromSeconds(5));var watch=Stopwatch.StartNew();var clock=new MonotonicClock();var starter=finalStarterForTest??new FixtureStarter("normal");byte[]? held=null;
        var client=finalClientForTest=new SelectionBrokerClient("public-fixture",starter,clock){ArmDeadlineForTest=useRealFinalDeadlineForTest?null:timer.Arm,BeforeSelectionDeliveryForTest=payload=>{held=payload;clock.Milliseconds+=elapsed;clock.Utc=clock.Utc.AddDays(-3);output.WriteLine($"SYNTHETIC FINAL HOOK fakeMs={clock.Milliseconds-10000} realMs={watch.Elapsed.TotalMilliseconds}");}};
        Exception? bodyFailure=null,disposeFailure=null;var original=client.CaptureAsync(Gesture(),guard.Token);
        try
        {
            var result=await original;timer.Dispose();
            var trace=new FinalBoundaryTrace(result.Status,held!=null,clock.Milliseconds-10000,watch.Elapsed.TotalMilliseconds,starter.Starts,starter is DelayedStarter delayed&&delayed.Entered.Task.IsCompletedSuccessfully,starter.Child!=null,client.ExitState);
            output.WriteLine($"SYNTHETIC CAPTURE RETURNED {trace}");observeFinalBoundaryForTest?.Invoke(trace);
            Assert.Equal(expected,result.Status);Assert.Equal(expected==SelectionCaptureStatus.Success?"public selected\n  code":"",result.Text);Assert.NotNull(held);Assert.All(held!,b=>Assert.Equal(0,b));if(expected==SelectionCaptureStatus.HardTimeout)Assert.Null(client.LastObservation);await client.DisposeAsync();Assert.Null(client.ExitState);Assert.Equal(1,starter.Starts);Assert.Equal(1,timer.Arms);Assert.Equal(TimeSpan.FromMilliseconds(600),timer.Due);Assert.Equal(0,timer.Fires);
        }
        catch(Exception error){bodyFailure=error;output.WriteLine($"SYNTHETIC BODY FAILED {error}");}
        finally{timer.Dispose();try{await SettleOriginalCapture(client,guard,original,starter as DelayedStarter,bodyFailure);}catch(Exception error){disposeFailure=error;output.WriteLine($"SYNTHETIC DISPOSE FAILED {error}");}}
        if(bodyFailure!=null&&disposeFailure!=null)throw new AggregateException("Selection body and original disposal failed.",bodyFailure,disposeFailure);
        if(bodyFailure!=null)ExceptionDispatchInfo.Capture(bodyFailure).Throw();if(disposeFailure!=null)ExceptionDispatchInfo.Capture(disposeFailure).Throw();
    }
    private static async Task SettleOriginalCapture(SelectionBrokerClient client,CancellationTokenSource guard,Task<SelectionCaptureResult> original,DelayedStarter? delayed,Exception? observed)
    {
        List<Exception> errors=[];try{guard.Cancel();}catch(Exception error){errors.Add(error);}finally{delayed?.Release.TrySetResult();}
        try{await original;}catch(Exception error){if(!ReferenceEquals(error,observed))errors.Add(error);}
        try{await client.DisposeAsync();}catch(Exception error){errors.Add(error);}
        if(errors.Count>0)throw new AggregateException("Original selection capture cleanup failed.",errors);
    }
    [Fact]public async Task HeldStartupProvesRealTimerCanRejectTheOriginal599ExpectationBeforeItsHook()
    {
        useRealFinalDeadlineForTest=true;Process? witness=null;var starter=new DelayedStarter{BeforeReturnForTest=child=>witness=Process.GetProcessById(child.Id)};finalStarterForTest=starter;FinalBoundaryTrace? observed=null;
        observeFinalBoundaryForTest=trace=>{observed=trace;starter.Release.TrySetResult();};
        try
        {
            try
            {
                var failure=await Record.ExceptionAsync(()=>FinalValidationUsesAbsoluteMonotonicDeadlineWithoutTimerCallback(599,SelectionCaptureStatus.Success));
                Assert.IsType<EqualException>(failure);Assert.Contains("Expected: Success",failure!.Message);Assert.Contains("Actual:   HardTimeout",failure.Message);
                Assert.NotNull(observed);Assert.Equal(SelectionCaptureStatus.HardTimeout,observed.Status);Assert.False(observed.HookEntered);Assert.Equal(0,observed.FakeMilliseconds);Assert.True(observed.StarterEntered);Assert.False(observed.StarterReturned);Assert.Equal(0,observed.Starts);Assert.Equal(HostExitState.ExitUnconfirmed,observed.Ownership);
            }
            finally{starter.Release.TrySetResult();if(finalClientForTest!=null)await finalClientForTest.DisposeAsync();}
            Assert.Equal(1,starter.Starts);Assert.Null(finalClientForTest!.ExitState);Assert.NotNull(witness);Assert.True(witness.HasExited);
        }
        finally{witness?.Dispose();}
    }
    [Theory][InlineData(true)][InlineData(false)]
    public async Task ControlledTimerStillRejectsStartupOrFinalDeliveryBeforeTheFakeAbsoluteBoundary(bool startup)
    {
        var clock=new MonotonicClock();using var timer=new ControlledDeadline();using var guard=new CancellationTokenSource(TimeSpan.FromSeconds(5));var delayed=startup?new DelayedStarter():null;FixtureStarter starter=delayed??new FixtureStarter("normal");byte[]? held=null;
        var client=new SelectionBrokerClient("public-fixture",starter,clock){ArmDeadlineForTest=timer.Arm,BeforeSelectionDeliveryForTest=bytes=>{held=bytes;clock.Milliseconds+=599;timer.Fire();}};
        var original=client.CaptureAsync(Gesture(),guard.Token);Exception? bodyFailure=null,cleanupFailure=null;
        try
        {
            if(delayed!=null){await delayed.Entered.Task.WaitAsync(TimeSpan.FromSeconds(5));Assert.False(original.IsCompleted);Assert.Equal(0,starter.Starts);timer.Fire();}
            var result=await original.WaitAsync(TimeSpan.FromSeconds(5));timer.Dispose();
            Assert.Equal(SelectionCaptureStatus.HardTimeout,result.Status);Assert.Equal("",result.Text);Assert.Null(client.LastObservation);Assert.True(clock.Milliseconds-10000<600);Assert.Equal(1,timer.Arms);Assert.Equal(TimeSpan.FromMilliseconds(600),timer.Due);Assert.Equal(1,timer.Fires);
            if(startup){Assert.Null(held);Assert.Equal(HostExitState.ExitUnconfirmed,client.ExitState);}else{Assert.NotNull(held);Assert.All(held,b=>Assert.Equal(0,b));}
        }
        catch(Exception error){bodyFailure=error;}
        finally{timer.Dispose();try{await SettleOriginalCapture(client,guard,original,delayed,bodyFailure);}catch(Exception error){cleanupFailure=error;}}
        if(bodyFailure!=null&&cleanupFailure!=null)throw new AggregateException("Controlled timer body and cleanup failed.",bodyFailure,cleanupFailure);
        if(bodyFailure!=null)ExceptionDispatchInfo.Capture(bodyFailure).Throw();if(cleanupFailure!=null)ExceptionDispatchInfo.Capture(cleanupFailure).Throw();
        Assert.Null(client.ExitState);Assert.Equal(1,starter.Starts);
    }
    [Fact]public async Task CancellationAtFinalValidationCannotDeliverDecodedSelection()
    {
        using var cancellation=new CancellationTokenSource();var starter=new FixtureStarter("normal");byte[]? held=null;await using var client=new SelectionBrokerClient("public-fixture",starter){BeforeSelectionDeliveryForTest=payload=>{held=payload;cancellation.Cancel();}};
        var result=await client.CaptureAsync(Gesture(),cancellation.Token);Assert.Equal(SelectionCaptureStatus.Cancelled,result.Status);Assert.Equal("",result.Text);Assert.NotNull(held);Assert.All(held!,b=>Assert.Equal(0,b));await client.DisposeAsync();Assert.Null(client.ExitState);Assert.Equal(1,starter.Starts);
    }
    private class FixtureStarter(string fault):IOwnedProcessStarter
    {
        public int Starts;public Process? Child;
        public virtual Process Start(ProcessStartInfo original)
        {
            Interlocked.Increment(ref Starts);string configuration=new DirectoryInfo(AppContext.BaseDirectory).Parent!.Name;
            string assembly=Path.GetFullPath(Path.Combine(AppContext.BaseDirectory,"../../../../../tools/KuaiYi.CaptureControlFixture/bin",configuration,"net10.0/KuaiYi.CaptureControlFixture.dll"));
            var info=OwnedProcessSession.Info(Environment.GetEnvironmentVariable("DOTNET_HOST_PATH")??"dotnet",null);info.ArgumentList.Clear();info.ArgumentList.Add(assembly);info.ArgumentList.Add("--selection-fixture");info.ArgumentList.Add(fault);foreach(string argument in original.ArgumentList.Take(9))info.ArgumentList.Add(argument);
            Assert.True(original.ArgumentList.Count is 9 or 10);
            if(original.ArgumentList.Count==10)Assert.Equal("--boundary-marker",original.ArgumentList[9]);
            return Child=Process.Start(info)??throw new IOException("Public fixture start failed.");
        }
    }
    private sealed class BoundaryStarter(Action enter,string fault="crash"):FixtureStarter(fault)
    {
        public override Process Start(ProcessStartInfo info)
        {
            enter();if(info.ArgumentList.Count==10&&info.ArgumentList[9]=="--boundary-marker")info.ArgumentList.RemoveAt(9);
            return base.Start(info);
        }
    }
    [Theory][InlineData(false)][InlineData(true)]
    public async Task OriginalNonzeroExitMayCarryOnlyItsReachedEnterOrReturnedBoundary(bool returned)
    {
        SelectionBoundaryMap? map=null;var starter=new BoundaryStarter(()=>{map!.Reach(SelectionBoundary.GetText,SelectionBoundaryPosition.Enter);if(returned)map.Reach(SelectionBoundary.GetText,SelectionBoundaryPosition.Returned);});
        await using var client=new SelectionBrokerClient("public-fixture",starter,boundaryDiagnostic:true){BoundaryFactoryForTest=id=>map=SelectionBoundaryMap.CreateAnonymousForTest(id)};
        var result=await client.CaptureAsync(Gesture(),default);Assert.Equal(SelectionCaptureStatus.Crash,result.Status);Assert.Equal("",result.Text);Assert.Null(client.LastObservation);Assert.Equal(23,client.LastProcessExitCode);
        Assert.Equal("Ready",client.BoundaryMarkerSetup);Assert.Equal(new SelectionReachedBoundary("GetText",returned?"Returned":"Enter",returned?2:1),client.LastReachedBoundary);
        await client.DisposeAsync();Assert.Null(client.ExitState);Assert.Throws<ObjectDisposedException>(()=>map!.Read(Guid.NewGuid()));
    }
    [Theory][InlineData("Stale")][InlineData("Corrupt")][InlineData("Unavailable")]
    public async Task UnavailableOrInvalidMarkerCannotChangeOriginalCrashOrCreateObservation(string mode)
    {
        SelectionBoundaryMap? map=null;var starter=new BoundaryStarter(()=>map?.Reach(mode=="Corrupt"?(SelectionBoundary)255:SelectionBoundary.GetSelection,SelectionBoundaryPosition.Enter));
        await using var client=new SelectionBrokerClient("public-fixture",starter,boundaryDiagnostic:true){BoundaryFactoryForTest=id=>mode=="Unavailable"?null:map=SelectionBoundaryMap.CreateAnonymousForTest(mode=="Stale"?Guid.NewGuid():id)};
        Assert.Equal(SelectionCaptureStatus.Crash,(await client.CaptureAsync(Gesture(),default)).Status);Assert.Null(client.LastReachedBoundary);Assert.Null(client.LastObservation);Assert.Equal(23,client.LastProcessExitCode);Assert.Equal(mode=="Unavailable"?"Unavailable":"Ready",client.BoundaryMarkerSetup);await client.DisposeAsync();Assert.Null(client.ExitState);
    }
    [Theory][InlineData(false)][InlineData(true)]
    public async Task CancellationOrAbsoluteDeadlineDuringMarkerValidationRejectsLateExitEvidence(bool cancelled)
    {
        var clock=new MonotonicClock();using var cancellation=new CancellationTokenSource();SelectionBoundaryMap? map=null;
        var starter=new BoundaryStarter(()=>map!.Reach(SelectionBoundary.GetText,SelectionBoundaryPosition.Enter));
        await using var client=new SelectionBrokerClient("public-fixture",starter,clock,boundaryDiagnostic:true){BoundaryFactoryForTest=id=>map=SelectionBoundaryMap.CreateAnonymousForTest(id),BeforeBoundaryDeliveryForTest=()=>{if(cancelled)cancellation.Cancel();else clock.Milliseconds+=600;}};
        Assert.Equal(cancelled?SelectionCaptureStatus.Cancelled:SelectionCaptureStatus.HardTimeout,(await client.CaptureAsync(Gesture(),cancellation.Token)).Status);
        Assert.Null(client.LastReachedBoundary);Assert.Null(client.LastProcessExitCode);Assert.Null(client.LastObservation);await client.DisposeAsync();Assert.Null(client.ExitState);Assert.Throws<ObjectDisposedException>(()=>map!.Read(Guid.NewGuid()));
    }
    [Theory][InlineData("normal",SelectionCaptureStatus.Success)][InlineData("broker-failure",SelectionCaptureStatus.Crash)][InlineData("identity",SelectionCaptureStatus.ProtocolFailure)]
    public async Task ExitZeroOrInvalidProtocolNeverBorrowsReachedMarker(string fault,SelectionCaptureStatus expected)
    {
        SelectionBoundaryMap? map=null;var starter=new BoundaryStarter(()=>map!.Reach(SelectionBoundary.GetText,SelectionBoundaryPosition.Enter),fault);
        await using var client=new SelectionBrokerClient("public-fixture",starter,boundaryDiagnostic:true){BoundaryFactoryForTest=id=>map=SelectionBoundaryMap.CreateAnonymousForTest(id)};
        Assert.Equal(expected,(await client.CaptureAsync(Gesture(),default)).Status);Assert.Null(client.LastReachedBoundary);Assert.Null(client.LastProcessExitCode);
        if(fault=="broker-failure")Assert.Equal("BrokerFailure",client.LastObservation?.Status);
        if(fault=="identity")Assert.Null(client.LastObservation);
        await client.DisposeAsync();Assert.Throws<ObjectDisposedException>(()=>map!.Read(Guid.NewGuid()));
    }
    [Fact]public async Task DisposeAfterOriginalExitBeforeDeliveryRejectsReachedEvidenceAndReleasesMapping()
    {
        SelectionBoundaryMap? map=null;var starter=new BoundaryStarter(()=>map!.Reach(SelectionBoundary.GetText,SelectionBoundaryPosition.Enter));
        var client=new SelectionBrokerClient("public-fixture",starter,boundaryDiagnostic:true){BoundaryFactoryForTest=id=>map=SelectionBoundaryMap.CreateAnonymousForTest(id)};
        client.BeforeBoundaryDeliveryForTest=()=>client.DisposeAsync().AsTask().GetAwaiter().GetResult();
        Assert.Equal(SelectionCaptureStatus.Cancelled,(await client.CaptureAsync(Gesture(),default)).Status);Assert.Null(client.LastReachedBoundary);Assert.Null(client.LastProcessExitCode);Assert.Null(client.ExitState);Assert.Throws<ObjectDisposedException>(()=>map!.Read(Guid.NewGuid()));
        await client.DisposeAsync();
    }
    [Fact]public async Task FreshMappingsKeepOriginalPauseAndNextPrecancelClearsReachedEvidence()
    {
        var maps=new List<SelectionBoundaryMap>();SelectionBoundaryMap? map=null;var starter=new BoundaryStarter(()=>map!.Reach(SelectionBoundary.GetSelection,SelectionBoundaryPosition.Enter));
        await using var client=new SelectionBrokerClient("public-fixture",starter,new Clock(),boundaryDiagnostic:true){BoundaryFactoryForTest=id=>{map=SelectionBoundaryMap.CreateAnonymousForTest(id);maps.Add(map);return map;}};
        for(int i=0;i<3;i++)
        {
            Assert.Equal(SelectionCaptureStatus.Crash,(await client.CaptureAsync(Gesture(),default)).Status);Assert.NotNull(client.LastReachedBoundary);
            using var guard=new CancellationTokenSource(TimeSpan.FromSeconds(5));while(client.ExitState!=null)await Task.Delay(5,guard.Token);
        }
        Assert.Equal(SelectionCaptureStatus.Paused,(await client.CaptureAsync(Gesture(),default)).Status);Assert.Null(client.LastReachedBoundary);Assert.Null(client.LastProcessExitCode);Assert.Equal("NotStarted",client.BoundaryMarkerSetup);Assert.Equal(3,starter.Starts);Assert.Equal(3,maps.Count);
        using var cancellation=new CancellationTokenSource();cancellation.Cancel();Assert.Equal(SelectionCaptureStatus.Cancelled,(await client.CaptureAsync(Gesture("other.exe"),cancellation.Token)).Status);Assert.Null(client.LastReachedBoundary);Assert.Equal(3,maps.Count);
        Assert.All(maps,m=>Assert.Throws<ObjectDisposedException>(()=>m.Read(Guid.NewGuid())));
    }
    [Fact]public async Task PendingOriginalStartupRetainsMappingUntilActualHeldChildSettlement()
    {
        var starter=new DelayedStarter();SelectionBoundaryMap? map=null;Guid request=default;
        var client=new SelectionBrokerClient("public-fixture",starter,boundaryDiagnostic:true){BoundaryFactoryForTest=id=>{request=id;return map=SelectionBoundaryMap.CreateAnonymousForTest(id);}};
        var pending=client.CaptureAsync(Gesture(),default);await starter.Entered.Task.WaitAsync(TimeSpan.FromSeconds(5));
        try{Assert.Equal(SelectionCaptureStatus.HardTimeout,(await pending).Status);Assert.Null(map!.Read(request));Assert.Equal(SelectionCaptureStatus.CleanupPending,(await client.CaptureAsync(Gesture(),default)).Status);Assert.Null(client.LastReachedBoundary);}
        finally{starter.Release.TrySetResult();await client.DisposeAsync();}
        Assert.Null(client.ExitState);Assert.Throws<ObjectDisposedException>(()=>map!.Read(request));
    }
    private static SelectionGesture Gesture(string application="public.exe")=>new(new(123,456,789,application),new(3,3),new(70,3),1,1);
    [Fact]public async Task APrecancelledAttemptCannotReuseThePreviousCompleteMetadata()
    {
        var starter=new FixtureStarter("normal");await using var client=new SelectionBrokerClient("public-fixture",starter);
        Assert.Equal(SelectionCaptureStatus.Success,(await client.CaptureAsync(Gesture(),default)).Status);Assert.Equal("Success",client.LastObservation?.Status);
        using var guard=new CancellationTokenSource(TimeSpan.FromSeconds(5));while(client.ExitState!=null)await Task.Delay(5,guard.Token);
        using var cancellation=new CancellationTokenSource();cancellation.Cancel();
        Assert.Equal(SelectionCaptureStatus.Cancelled,(await client.CaptureAsync(Gesture(),cancellation.Token)).Status);Assert.Null(client.LastObservation);Assert.Null(client.LastProcessExitCode);Assert.Equal(1,starter.Starts);
    }
    [Fact]public async Task CompleteReportedBrokerFailureStillCountsTowardTheOriginalPauseRule()
    {
        var starter=new FixtureStarter("broker-failure");var clock=new Clock();await using var client=new SelectionBrokerClient("public-fixture",starter,clock);
        for(int i=0;i<3;i++)
        {
            var result=await client.CaptureAsync(Gesture(),default);Assert.Equal(SelectionCaptureStatus.Crash,result.Status);Assert.Equal("",result.Text);
            Assert.Equal("BrokerFailure",client.LastObservation?.Status);Assert.Equal("MetadataSerialize",client.LastObservation?.Stage);Assert.Equal("Argument",client.LastObservation?.Exception);
            Assert.Equal(unchecked((int)0x80070057),client.LastObservation?.HResult);Assert.Null(client.LastProcessExitCode);
            using var guard=new CancellationTokenSource(TimeSpan.FromSeconds(5));while(client.ExitState!=null)await Task.Delay(5,guard.Token);
        }
        Assert.Equal(SelectionCaptureStatus.Paused,(await client.CaptureAsync(Gesture(),default)).Status);Assert.Null(client.LastObservation);Assert.Null(client.LastProcessExitCode);Assert.Equal(3,starter.Starts);
    }
    [Fact]public async Task PrecancelledAttemptAndCleanupCannotReuseOriginalCrashExitCode()
    {
        var starter=new FixtureStarter("crash");await using var client=new SelectionBrokerClient("public-fixture",starter);
        Assert.Equal(SelectionCaptureStatus.Crash,(await client.CaptureAsync(Gesture(),default)).Status);Assert.Equal(23,client.LastProcessExitCode);
        using var guard=new CancellationTokenSource(TimeSpan.FromSeconds(5));while(client.ExitState!=null)await Task.Delay(5,guard.Token);
        Assert.Equal(23,client.LastProcessExitCode);
        using var cancellation=new CancellationTokenSource();cancellation.Cancel();
        Assert.Equal(SelectionCaptureStatus.Cancelled,(await client.CaptureAsync(Gesture(),cancellation.Token)).Status);Assert.Null(client.LastProcessExitCode);Assert.Null(client.LastObservation);Assert.Equal(1,starter.Starts);
    }
    [Theory][InlineData("normal",SelectionCaptureStatus.Success)][InlineData("identity",SelectionCaptureStatus.ProtocolFailure)][InlineData("role",SelectionCaptureStatus.ProtocolFailure)][InlineData("source",SelectionCaptureStatus.ProtocolFailure)][InlineData("runtime",SelectionCaptureStatus.ProtocolFailure)][InlineData("bounds",SelectionCaptureStatus.ProtocolFailure)][InlineData("oversize",SelectionCaptureStatus.ProtocolFailure)][InlineData("extra",SelectionCaptureStatus.ProtocolFailure)][InlineData("soft",SelectionCaptureStatus.SoftTimeout)][InlineData("error-text",SelectionCaptureStatus.EmptyOrUnsupported)][InlineData("crash",SelectionCaptureStatus.Crash)]
    public async Task ActualOwnedFixtureEnforcesSelectionWireAndIdentity(string fault,SelectionCaptureStatus expected)
    {
        var starter=new FixtureStarter(fault);await using var client=new SelectionBrokerClient("public-fixture",starter);var result=await client.CaptureAsync(Gesture(),default);Assert.Equal(expected,result.Status);Assert.Equal(1,starter.Starts);
        Assert.Equal(expected==SelectionCaptureStatus.Crash?23:(int?)null,client.LastProcessExitCode);
        if(expected==SelectionCaptureStatus.Crash)Assert.Null(client.LastObservation);
        if(expected==SelectionCaptureStatus.Success){Assert.Equal("public selected\n  code",result.Text);Assert.Equal(new[]{12,4},result.RuntimeId);Assert.Equal(new PixelRect(0,0,100,20),Assert.Single(result.Ranges));}else Assert.Equal("",result.Text);
    }
    [Theory][InlineData("hang")][InlineData("late")]
    public async Task HardDeadlineReturnsBeforeCleanupAndHeldChildActuallyExits(string fault)
    {
        var starter=new FixtureStarter(fault);var client=new SelectionBrokerClient("public-fixture",starter);var watch=Stopwatch.StartNew();var result=await client.CaptureAsync(Gesture(),default);Assert.Equal(SelectionCaptureStatus.HardTimeout,result.Status);Assert.True(watch.Elapsed<TimeSpan.FromSeconds(2));Assert.Equal("",result.Text);await client.DisposeAsync();Assert.Null(client.ExitState);Assert.Null(client.LastProcessExitCode);Assert.Equal(1,starter.Starts);
    }
    [Fact]public async Task CancellationDuringActualChildWaitNeverAllowsLateText()
    {
        var starter=new FixtureStarter("cancel");await using var client=new SelectionBrokerClient("public-fixture",starter);using var cancellation=new CancellationTokenSource();var pending=client.CaptureAsync(Gesture(),cancellation.Token);
        using var guard=new CancellationTokenSource(TimeSpan.FromSeconds(5));while(starter.Child==null)await Task.Delay(5,guard.Token);cancellation.Cancel();Assert.Equal(SelectionCaptureStatus.Cancelled,(await pending).Status);await client.DisposeAsync();Assert.Null(client.ExitState);
    }
    private sealed class Clock:TimeProvider{public DateTimeOffset Now=DateTimeOffset.UtcNow;public override DateTimeOffset GetUtcNow()=>Now;}
    private sealed class DelayedStarter(string fault="hang"):FixtureStarter(fault)
    {
        public readonly TaskCompletionSource Entered=new(TaskCreationOptions.RunContinuationsAsynchronously),Release=new(TaskCreationOptions.RunContinuationsAsynchronously);public int Entries;public Action<Process>? BeforeReturnForTest{get;init;}
        public override Process Start(ProcessStartInfo info){Interlocked.Increment(ref Entries);Entered.TrySetResult();Release.Task.GetAwaiter().GetResult();var child=base.Start(info);BeforeReturnForTest?.Invoke(child);return child;}
    }
    [Fact]public async Task HardDeadlineDuringStartupRetainsOwnershipAndForbidsSecondWriterUntilLateChildSettles()
    {
        var starter=new DelayedStarter();var client=new SelectionBrokerClient("public-fixture",starter);var pending=client.CaptureAsync(Gesture(),default);await starter.Entered.Task.WaitAsync(TimeSpan.FromSeconds(5));
        try{Assert.Equal(SelectionCaptureStatus.HardTimeout,(await pending).Status);Assert.Equal(SelectionCaptureStatus.CleanupPending,(await client.CaptureAsync(Gesture(),default)).Status);Assert.Equal(1,starter.Entries);Assert.Equal(0,starter.Starts);}
        finally{starter.Release.TrySetResult();await client.DisposeAsync();}
        Assert.Equal(1,starter.Starts);Assert.Null(client.ExitState);
    }
    [Fact]public async Task ThreeActualCrashesPauseOnlyThatApplicationAndResumeAfterThirtySeconds()
    {
        var starter=new FixtureStarter("crash");var clock=new Clock();await using var client=new SelectionBrokerClient("public-fixture",starter,clock);
        for(int i=0;i<3;i++)Assert.Equal(SelectionCaptureStatus.Crash,(await client.CaptureAsync(Gesture(),default)).Status);
        Assert.Equal(SelectionCaptureStatus.Paused,(await client.CaptureAsync(Gesture(),default)).Status);Assert.Null(client.LastProcessExitCode);Assert.Equal(3,starter.Starts);
        Assert.Equal(SelectionCaptureStatus.Crash,(await client.CaptureAsync(Gesture("other.exe"),default)).Status);clock.Now=clock.Now.AddSeconds(31);Assert.Equal(SelectionCaptureStatus.Crash,(await client.CaptureAsync(Gesture(),default)).Status);Assert.Equal(5,starter.Starts);
    }
}
