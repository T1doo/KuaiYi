from pathlib import Path
import subprocess,json,datetime
root=Path('/workspace/KuaiYi');out=root/'artifacts/file-image-ocr';commands=[]
def run(name,args):
    command=['python3','-B','scripts/session-sdk.py',*args]
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (out/(name+'.log')).open('w') as log: result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    commands.append(dict(name=name,command=command,start=start,exit=result.returncode))
    (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    if result.returncode: raise SystemExit(result.returncode)
common=['-c','Release','--no-restore','-nodeReuse:false','-p:UseSharedCompilation=false']
run('r03-provider-file', ['test','tests/KuaiYi.Provider.Tests/KuaiYi.Provider.Tests.csproj',*common,'--filter','FullyQualifiedName~FileImageOcrTests','--logger','trx;LogFileName=r03-provider-file.trx','--results-directory',str(out)])
run('r04-provider-full',['test','tests/KuaiYi.Provider.Tests/KuaiYi.Provider.Tests.csproj',*common,'--no-build','--logger','trx;LogFileName=r04-provider-full.trx','--results-directory',str(out)])
run('r05-codec-full',['test','tests/KuaiYi.Codec.Tests/KuaiYi.Codec.Tests.csproj',*common,'--logger','trx;LogFileName=r05-codec-full.trx','--results-directory',str(out)])
run('r06-core-related',['test','tests/KuaiYi.Core.Tests/KuaiYi.Core.Tests.csproj',*common,'--filter','FullyQualifiedName~Ocr|FullyQualifiedName~ImageSource|FullyQualifiedName~Screenshot|FullyQualifiedName~RuntimeGate|FullyQualifiedName~RequestIdentity|FullyQualifiedName~SourceOwnership|FullyQualifiedName~ImageFileDrop','--logger','trx;LogFileName=r06-core-related.trx','--results-directory',str(out)])
for name,project in [('r07-restore-worker','src/KuaiYi.ImageWorker/KuaiYi.ImageWorker.csproj'),('r08-restore-app','src/KuaiYi.App/KuaiYi.App.csproj')]:
    run(name,['restore',project,'--locked-mode','-p:NuGetAudit=true','-p:NuGetAuditMode=all','-p:NuGetAuditLevel=low','-p:EnableWindowsTargeting=true','-nodeReuse:false','-p:UseSharedCompilation=false'])
for name,project in [('r09-build-worker','src/KuaiYi.ImageWorker/KuaiYi.ImageWorker.csproj'),('r10-build-app','src/KuaiYi.App/KuaiYi.App.csproj')]:
    run(name,['build',project,*common,'-p:EnableWindowsTargeting=true'])
