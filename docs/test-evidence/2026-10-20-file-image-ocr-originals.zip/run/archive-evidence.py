from pathlib import Path
import subprocess,json,hashlib,zipfile,xml.etree.ElementTree as ET
r=Path('/workspace/KuaiYi');out=r/'artifacts/file-image-ocr';base='31ee5704fe1e210556a4c2d70e80b811d3a75634';sha=lambda b:hashlib.sha256(b).hexdigest()
tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',base],cwd=r,text=True).splitlines()
changed=subprocess.check_output(['git','diff','--name-only',base],cwd=r,text=True).splitlines()
product=[p for p in changed if p.startswith('src/')]
new=['tests/KuaiYi.Provider.Tests/FileImageOcrTests.cs','tests/KuaiYi.Codec.Tests/DecodedFileOcrTests.cs']
source=product+new+['docs/validation/file-image-ocr.md','docs/progress.md','docs/acceptance-report.md']
(out/'source-hashes.json').write_text(json.dumps({p:sha((r/p).read_bytes()) for p in source},indent=2)+'\n')
protected={}
for p in tracked:
 if p in changed:continue
 if p in ['SPEC.md','快译_产品与技术开发规格_v1.0.md','AGENTS.md','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json'] or p.endswith('packages.lock.json') or p.startswith(('licenses/','LICENSES/')) or (p.startswith(('src/','tests/')) and p.endswith(('.cs','.csproj'))):
  before=subprocess.check_output(['git','show',f'{base}:{p}'],cwd=r);after=(r/p).read_bytes()
  if before!=after:raise RuntimeError('Protected change: '+p)
  protected[p]=dict(base=sha(before),current=sha(after),equal=True)
(out/'protected-hashes.json').write_text(json.dumps(protected,indent=2)+'\n')
products={}
for directory in ['src/KuaiYi.App/bin/Release','src/KuaiYi.ImageWorker/bin/Release','tests/KuaiYi.Provider.Tests/bin/Release','tests/KuaiYi.Codec.Tests/bin/Release','tests/KuaiYi.Core.Tests/bin/Release','tools/KuaiYi.ImageDecodeFixture/bin/Release']:
 for path in sorted((r/directory).rglob('*')):
  if path.is_file() and path.suffix in ['.dll','.exe','.so','.json','.pdb']:products[str(path.relative_to(r))]=sha(path.read_bytes())
(out/'product-hashes.json').write_text(json.dumps(products,indent=2)+'\n')
results={};ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
for p in sorted(out.glob('*.trx')):
 tree=ET.parse(p);counts=tree.find('t:ResultSummary/t:Counters',ns);tests=tree.findall('t:Results/t:UnitTestResult',ns)
 results[p.name]=dict(counts=counts.attrib,results=len(tests),sha256=sha(p.read_bytes()))
(out/'trx-index.json').write_text(json.dumps(results,indent=2)+'\n')
review='''Read-only independent agent gif_review: design limited ACK before implementation, no definite P1/P2; required precise late-modal rejection. Five product files limited source ACK after implementation, no definite P1/P2; independently checked prepared original-task lifetime, actual dimensions/caps, validated immutable mapping, exact owner/proof and ref-specific RejectPreview plus unchanged confirmation path. Reviewer did not write, test, build or run Windows. Final evidence review pending separately.\n'''
(out/'review-scope.txt').write_text(review)
files={}
for p in out.iterdir():
 if p.is_file() and p.suffix in ['.log','.trx','.json','.md','.py','.txt'] and p.name!='post-push-verification.json':files['run/'+p.name]=p.read_bytes()
for p in source:files['source/'+p]=(r/p).read_bytes()
manifest={p:dict(bytes=len(b),sha256=sha(b)) for p,b in files.items()}
archive=r/'docs/test-evidence/2026-10-20-file-image-ocr-originals.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p,b in files.items():z.writestr(p,b)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
index=dict(date='2026-10-20',base_sha=base,branch='dev/p6-file-image-ocr',single_writer='root; one worktree; existing reviewer read-only; old instances not resumed',environment='designated saved Linux x64; SDK10.0.402/runtime10.0.13',commands=json.loads((out/'commands.json').read_text()),results=results,final=dict(provider_full=2427,codec_full=478,core_related=114,provider_new=34,codec_new=3,failures=0,skipped=0,worker_build='0W/0E',app_build='0W/0E',locked_audited_restore=2),scope=dict(actual='Linux native decoder/private worker PNG/JPEGEXIF6/GIF -> actual file owner and OCR coordinator; actual Linux OCR Worker UnsupportedPlatform; actual two-protocol loopback HTTP text',synthetic='prepared-file owners in Provider tests; successful OCR and installed capabilities port; no native Windows success',new_tests_unchanged_old_tests=True),source_hashes=json.loads((out/'source-hashes.json').read_text()),protected=dict(count=len(protected),all_equal=True,catalog='run/protected-hashes.json'),products=dict(count=len(products),catalog='run/product-hashes.json'),independent_review='design and five-product-file limited ACK; read-only, no tests/build; final evidence review recorded in final report',failures_preserved=['build-first.log: App0W/2E notice variable collision, renamed','provider-first.log: ApiProtocol ambiguity, 0 executed; explicit alias added','old BMP historical469P/1F then2P then470P: cause remains UNKNOWN; not attributed to this work'],not_run=['Windows OLE/COM/WPF/native OCR and installed identity/languages','real source/password/integrity/final-filehandle','quality/font review','250/600ms','600MiB','full P6/Beta'],constraints=['WebP odd payload explicitly rejected','PackageHold','production image reuse Off','no new dependency/license/permission/cost/credential','no live model/private data/user desktop/deployment/main/force push','bitmap/virtual file/multi-image not expanded'],archive=dict(path=str(archive.relative_to(r)),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),entries=len(manifest)+1))
(r/'docs/test-evidence/2026-10-20-file-image-ocr.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(source=len(source),protected=len(protected),products=len(products),trx=len(results),archive=index['archive']),indent=2))
