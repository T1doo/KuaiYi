using KuaiYi.Core.Installation;
using Xunit;
namespace KuaiYi.Core.Tests;
public sealed class InstallationWarmActorTests
{
    private static readonly TimeSpan Guard=TimeSpan.FromSeconds(5);
    private static TaskCompletionSource Signal()=>new(TaskCreationOptions.RunContinuationsAsynchronously);
    [Fact]public async Task QuiesceHasAlreadyRevokedBeforeTheCancellationSourceStartsAndCannotLoseToAccept()
    {
        var admission=new InstallationWarmImageAdmission(InstallationWarmImageTests.Proof(),new InstallationWarmImageTests.Clock());var lease=admission.Reserve(new(),4);admission.Commit(lease,new(lease.Grant,"C:\\public\\a.png"));
        var before=Signal();var release=Signal();lease.BeforeCancellationForTest=()=>{before.TrySetResult();release.Task.GetAwaiter().GetResult();};
        var quiesce=Task.Run(async()=>await admission.Quiesce());
        try
        {
            await before.Task.WaitAsync(Guard);Assert.False(lease.Token.IsCancellationRequested);Assert.Equal(InstallationWarmPhase.Revoked,admission.Phase(lease));
            int invoked=0;Assert.False(admission.TryAccept(lease,()=>{invoked++;return new(Guid.NewGuid(),1);}));Assert.Equal(0,invoked);
        }
        finally{release.TrySetResult();await quiesce.WaitAsync(Guard);}
        Assert.True(await admission.RetireAsync(lease,()=>ValueTask.FromResult(true),_=>Task.CompletedTask));
    }
    [Fact]public async Task QuiescePublishesTheOriginalWriteBeforeCallingASynchronouslyBlockingSender()
    {
        var entered=Signal();var release=Signal();var actor=new InstallationWarmImageControl(InstallationWarmImageTests.Proof(),new InstallationWarmImageTests.Clock(),()=>3,(_,_,_,_)=>Task.CompletedTask,_=>ValueTask.FromResult(true),(line,_)=>(line.StartsWith("WARM_QUIESCE|",StringComparison.Ordinal)?Block():Task.CompletedTask));
        Task Block(){entered.TrySetResult();release.Task.GetAwaiter().GetResult();return Task.CompletedTask;}
        Task quiesce=Task.Run(actor.Quiesce);await entered.Task.WaitAsync(Guard);
        try{await quiesce.WaitAsync(Guard);var settling=actor.SettleAsync();Assert.False(settling.IsCompleted);release.TrySetResult();await settling.WaitAsync(Guard);}
        finally{release.TrySetResult();await actor.SettleAsync().WaitAsync(Guard);}
    }
    [Theory][InlineData(false)][InlineData(true)]
    public async Task ChildDeadlinesSettleWithoutAClientTimerOrCancellationMessage(bool preparing)
    {
        var proof=InstallationWarmImageTests.Proof();var clock=new InstallationWarmImageTests.Clock();var issuer=new InstallationWarmImageAdmission(proof,new InstallationWarmImageTests.Clock());var issued=issuer.Reserve(new(),3);
        var grant=new TaskCompletionSource<InstallationWarmGrant>(TaskCreationOptions.RunContinuationsAsynchronously);var terminal=new TaskCompletionSource<InstallationWarmResult>(TaskCreationOptions.RunContinuationsAsynchronously);
        var entered=Signal();var release=Signal();int accepts=0;
        var actor=new InstallationWarmImageControl(proof,clock,()=>3,async(admission,lease,_,_)=>
        {entered.TrySetResult();await release.Task;admission.TryAccept(lease,()=>{accepts++;return new(Guid.NewGuid(),1);});},_=>ValueTask.FromResult(true),(line,_)=>
        {if(line.StartsWith("WARM_GRANTED|",StringComparison.Ordinal))grant.TrySetResult(InstallationWarmImageWire.Decode<InstallationWarmGrant>(line[13..]));if(line.StartsWith("WARM_RESULT|",StringComparison.Ordinal))terminal.TrySetResult(InstallationWarmImageWire.Decode<InstallationWarmResult>(line[12..]));return Task.CompletedTask;});
        actor.Handle("WARM_RESERVE|"+InstallationWarmImageWire.Encode(issued.Grant.Identity));var bound=await grant.Task.WaitAsync(Guard);
        try
        {
            Task change=actor.NextCompletionChange;
            if(preparing)
            {
                actor.Handle("WARM_COMMIT|"+InstallationWarmImageWire.Encode(new InstallationWarmSubmit(bound,"C:\\public\\a.png")));await entered.Task.WaitAsync(Guard);
                clock.Advance(15000);Assert.True(actor.Admission.Busy);Assert.False(terminal.Task.IsCompleted);release.TrySetResult();
            }
            else{clock.Advance(10000);await change.WaitAsync(Guard);}
            Assert.Equal(InstallationWarmOutcome.Rejected,(await terminal.Task.WaitAsync(Guard)).Outcome);Assert.True(await actor.OriginalCompletion.WaitAsync(Guard));Assert.False(actor.Admission.Busy);Assert.Equal(0,accepts);
        }
        finally{release.TrySetResult();await actor.SettleAsync().WaitAsync(Guard);await issuer.Revoke(issued);Assert.True(await issuer.RetireAsync(issued,()=>ValueTask.FromResult(true),_=>Task.CompletedTask));}
    }
}
