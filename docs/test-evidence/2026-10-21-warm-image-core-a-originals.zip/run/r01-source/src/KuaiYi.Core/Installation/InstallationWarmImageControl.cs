namespace KuaiYi.Core.Installation;

// Internal stage-A opt-in, reached only by the synthetic installation fixture. The App does not attach it.
internal sealed class InstallationWarmImageControl
{
    private readonly InstallationControlledLaunch proof;
    private readonly Func<long> epoch;
    private readonly Func<InstallationWarmImageAdmission,InstallationWarmLease,string,CancellationToken,Task> prepare;
    private readonly Func<InstallationWarmLease,ValueTask<bool>> finalize;
    private readonly Func<string,CancellationToken,Task> send;
    private readonly object sync=new();
    private InstallationWarmLease? current;
    private Task completion=Task.CompletedTask,quiesceWrite=Task.CompletedTask;
    private bool quiesced;
    internal readonly InstallationWarmImageAdmission Admission;
    internal bool EverReserved{get;private set;}
    internal InstallationWarmImageControl(InstallationControlledLaunch proof,TimeProvider clock,Func<long> epoch,
        Func<InstallationWarmImageAdmission,InstallationWarmLease,string,CancellationToken,Task> prepare,
        Func<InstallationWarmLease,ValueTask<bool>> finalize,Func<string,CancellationToken,Task> send)
    {this.proof=proof;this.epoch=epoch;this.prepare=prepare;this.finalize=finalize;this.send=send;Admission=new(proof,clock);}
    internal bool Handle(string line)
    {lock(sync)return HandleCore(line);}
    private bool HandleCore(string line)
    {
        if(line.StartsWith("WARM_RESERVE|",StringComparison.Ordinal))
        {
            if(quiesced||!completion.IsCompletedSuccessfully)throw new InvalidDataException("Warm request unavailable.");
            var identity=InstallationWarmImageWire.Decode<InstallationWarmIdentity>(line[13..]);
            var lease=Admission.ReceiveReserve(identity,epoch());current=lease;EverReserved=true;
            _=Admission.RunOwned(lease,ct=>send("WARM_GRANTED|"+InstallationWarmImageWire.Encode(lease.Grant),ct));return true;
        }
        if(line.StartsWith("WARM_COMMIT|",StringComparison.Ordinal))
        {
            var submit=InstallationWarmImageWire.Decode<InstallationWarmSubmit>(line[12..]);var lease=Require(submit.Grant.Identity);
            if(!Admission.Commit(lease,submit)){Complete(lease,Task.CompletedTask);return true;}
            Task work=Admission.RunOwned(lease,ct=>prepare(Admission,lease,submit.Path,ct));Complete(lease,work);return true;
        }
        if(line.StartsWith("WARM_CANCEL|",StringComparison.Ordinal))
        {
            var identity=InstallationWarmImageWire.Decode<InstallationWarmIdentity>(line[12..]);var lease=Require(identity);
            _=Admission.Revoke(lease);
            if(completion.IsCompletedSuccessfully)Complete(lease,Task.CompletedTask);return true;
        }
        return false;
    }
    private InstallationWarmLease Require(InstallationWarmIdentity identity)
    {
        identity.Require(proof);
        if(current is not {} lease||lease.Grant.Identity!=identity)throw new InvalidDataException("Warm request identity mismatch.");return lease;
    }
    private void Complete(InstallationWarmLease lease,Task work)
    {
        completion=work.ContinueWith(async _=>
        {
            // RetireAsync observes this exact work task, including its original failure, after cancellation starts.
            if(Admission.Phase(lease)==InstallationWarmPhase.Preparing)_=Admission.Revoke(lease);
            bool retired=await Admission.RetireAsync(lease,()=>finalize(lease),result=>send("WARM_RESULT|"+InstallationWarmImageWire.Encode(result),CancellationToken.None)).ConfigureAwait(false);
            if(!retired)throw new IOException("Original warm owner cleanup unconfirmed.");
            lock(sync)if(ReferenceEquals(current,lease))current=null;
        },CancellationToken.None,TaskContinuationOptions.ExecuteSynchronously,TaskScheduler.Default).Unwrap();
    }
    internal void Quiesce(){lock(sync)QuiesceCore();}
    private void QuiesceCore()
    {
        if(quiesced)return;quiesced=true;
        _=Admission.Quiesce(); // Raw revocation must happen before any wait on the writer.
        quiesceWrite=send($"WARM_QUIESCE|{proof.Launch:N}|{proof.Fingerprint}",CancellationToken.None);
        if(current is {} lease&&completion.IsCompletedSuccessfully)Complete(lease,Task.CompletedTask);
    }
    internal async Task SettleAsync()
    {
        Task original,notice;lock(sync){QuiesceCore();original=completion;notice=quiesceWrite;}List<Exception> errors=[];
        try{await original.ConfigureAwait(false);}catch(Exception error){errors.Add(error);}
        try{await notice.ConfigureAwait(false);}catch(Exception error){errors.Add(error);}
        if(errors.Count!=0)throw new AggregateException("Original warm control unconfirmed.",errors);
    }
}
