from pathlib import Path
import subprocess,json,hashlib,sys,time,xml.etree.ElementTree as E,re
out=Path('artifacts/warm-image-a');name=sys.argv[1];cmd=['python3','-B','scripts/session-sdk.py',*sys.argv[2:]]
assert not(out/(name+'.json')).exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inputs():
 paths=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z'],text=True).split('\0');return {p:sha(Path(p))for p in paths if p and(p.startswith(('src/','tests/','tools/','assets/','scripts/','packaging/'))or p.startswith('Directory.')or p in('SPEC.md','AGENTS.md','global.json','NuGet.Config','KuaiYi.sln'))}
before=inputs();(out/(name+'-inputs.json')).write_text(json.dumps(before,indent=2)+'\n')
for p in before:
 if 'InstallationWarm' in p or p.endswith(('InstallationApplicationControl.cs','InstallationAppControlFixture.cs','InstallationAppControlFixture.Warm.cs','InstallationSessionTests.cs')):
  q=out/(name+'-source')/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(Path(p).read_bytes())
start=time.monotonic()
with(out/(name+'.log')).open('w')as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
row={'command':cmd,'exitCode':code,'seconds':round(time.monotonic()-start,3),'inputsUnchangedDuringRun':before==inputs(),'logSha256':sha(out/(name+'.log'))};trx=out/(name+'.trx')
if trx.exists():
 ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};tree=E.parse(trx);row['counts']=tree.find('.//t:Counters',ns).attrib;row['trxSha256']=sha(trx);raw=trx.read_text(encoding='utf-8-sig');fails=re.findall(r'<UnitTestResult\b(?=[^>]*outcome="(?:Failed|Error|Aborted|Timeout)")[^>]*>.*?</UnitTestResult>',raw,re.S)
 for i,x in enumerate(fails,1):(out/f'{name}-failure-{i:03d}.xml').write_text(x+'\n')
 row['failures']=len(fails)
(out/(name+'-dlls.json')).write_text(json.dumps({str(p):sha(p)for d in('src','tests','tools')for p in Path(d).rglob('*.dll')if'/bin/Release/'in str(p)},indent=2)+'\n');(out/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row,indent=2),flush=True);print((out/(name+'.log')).read_text()[-12000:],flush=True)
