from pathlib import Path
import subprocess,json,hashlib,datetime,time,re,xml.etree.ElementTree as E
root=Path.cwd();out=root/'artifacts/core-post-fix-signoff';expected='00f80840b8dede4019208dc0f4d8f2f60b7ce90a'
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sources():
 paths=git('ls-files','-z').split('\0');return {p:digest(root/p) for p in paths if p and (p.startswith(('src/','tests/','tools/','assets/','scripts/','packaging/')) or p.startswith('Directory.') or p in ('KuaiYi.sln','global.json','NuGet.Config','SPEC.md','AGENTS.md'))}
def products():return {str(p.relative_to(root)):digest(p) for base in ('src','tests','tools') for p in (root/base).rglob('*.dll') if '/bin/Release/' in str(p)}
assert git('rev-parse','HEAD')==expected and not git('status','--porcelain=v1')
assert not (out/'result.json').exists(),'This signoff must run exactly once'
before=sources();(out/'sources-before.json').write_text(json.dumps(before,ensure_ascii=False,indent=2)+'\n');(out/'dlls-before.json').write_text(json.dumps(products(),indent=2)+'\n')
command=['python3','-B','scripts/session-sdk.py','test','tests/KuaiYi.Core.Tests/KuaiYi.Core.Tests.csproj','-c','Release','--no-restore','-nodeReuse:false','-p:UseSharedCompilation=false','--logger','trx;LogFileName=full-core-fixed-head.trx','--results-directory',str(out)]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();monotonic=time.monotonic();(out/'command.json').write_text(json.dumps(dict(fixedHead=expected,command=command,started=started),indent=2)+'\n')
with (out/'full-core-fixed-head.log').open('w') as f:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
source_after=sources();after=products();(out/'sources-after.json').write_text(json.dumps(source_after,ensure_ascii=False,indent=2)+'\n');(out/'dlls-after.json').write_text(json.dumps(after,indent=2)+'\n')
trx=out/'full-core-fixed-head.trx';counts=None;failures=[]
if trx.exists():
 tree=E.parse(trx);ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};counts=tree.find('.//t:Counters',ns).attrib;raw=trx.read_text(encoding='utf-8-sig');failures=re.findall(r'<UnitTestResult\b(?=[^>]*outcome="(?:Failed|Error|Aborted|Timeout)")[^>]*>.*?</UnitTestResult>',raw,re.S)
 for i,record in enumerate(failures,1):(out/f'failure-{i:03d}-UnitTestResult.xml').write_text(record+'\n')
result=dict(fixedHead=expected,command=command,started=started,seconds=round(time.monotonic()-monotonic,3),exitCode=code,counts=counts,failedOriginalResults=len(failures),sourceCount=len(before),sourcesBeforeAfterEqual=before==source_after,headStillFixed=git('rev-parse','HEAD')==expected,dirtyAfter=git('status','--porcelain=v1'),trxSha256=digest(trx) if trx.exists() else None)
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
