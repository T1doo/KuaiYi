import hashlib,json,subprocess,zipfile,xml.etree.ElementTree as ET
from pathlib import Path
root=Path.cwd();out=root/'artifacts/browser-image-preview'; target=root/'docs/test-evidence';ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
results={}
for p in sorted(out.glob('*.trx')):
 tree=ET.parse(p);counter=tree.find('.//t:Counters',ns);rows=tree.findall('.//t:UnitTestResult',ns)
 results[p.name]={'counts':counter.attrib,'results':len(rows),'sha256':sha(p)}
for name,passed,failed in [('r13-core-full.trx',2069,1),('r24-core-full-check.trx',2069,1),('r14-provider-full.trx',2436,0),('r15-codec-full.trx',481,0)]:
 c=results[name]['counts'];assert int(c['passed'])==passed and int(c['failed'])==failed and int(c['notExecuted'])==0
core=[]
for name in ('r13-core-full.trx','r24-core-full-check.trx'):
 rows=ET.parse(out/name).findall('.//t:UnitTestResult',ns);new=[r for r in rows if 'BrowserImageReceptionTests.' in r.attrib['testName']];fail=[r.attrib['testName'] for r in rows if r.attrib['outcome']!='Passed'];assert len(new)==14 and all(r.attrib['outcome']=='Passed' for r in new)
 core.append({'run':name,'status':'Fail','newBrowserTestsPassed':14,'failingTestNames':fail,'rootCause':'UNKNOWN; final Cleanup:69 may mask a body failure; relationship to browser patch not established'})
tracked=subprocess.check_output(['git','ls-files','-z']).decode().split('\0');tracked=[p for p in tracked if p]
changes=subprocess.check_output(['git','diff','--name-only','-z']).decode().split('\0')+subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z']).decode().split('\0');changes=[p for p in changes if p and Path(p).is_file()]
source={p:sha(root/p) for p in changes if p.startswith(('src/','tests/','docs/validation/')) or p in ('docs/progress.md','docs/acceptance-report.md')}
(out/'source-hashes.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n')
products={str(p.relative_to(root)):sha(p) for base in ('src','tests','tools') for p in (root/base).rglob('*') if p.is_file() and '/bin/Release/' in str(p) and p.suffix in ('.dll','.json','.exe')}
(out/'product-hashes.json').write_text(json.dumps(products,ensure_ascii=False,indent=2)+'\n')
protected=json.loads((out/'protected-hashes.json').read_text());assert all(r['equal'] and sha(root/r['path'])==r['sha256'] for r in protected)
archive=target/'2026-10-21-browser-image-preview-originals.zip'
entries={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(out.iterdir()):
  if p.is_file():
   key='run/'+p.name;z.write(p,key);entries[key]={'bytes':p.stat().st_size,'sha256':sha(p)}
 for p in source:
  key='final-source/'+p;z.write(root/p,key);entries[key]={'bytes':(root/p).stat().st_size,'sha256':sha(root/p)}
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,record in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==record['sha256']
index={'date':'2026-10-21','base_sha':'1eeb40444d718d8d92529207220cdc17ca0c076e','branch':'dev/p7-browser-image-preview','single_writer':'root, one worktree; reviewer read-only; no old writer resumed; unknown locks retained','environment':'designated saved Linux x64; SDK10.0.402/runtime10.0.13','commands':json.loads((out/'final-checks.json').read_text())+json.loads((out/'followup-checks.json').read_text()),'results':results,'final':{'provider_full':2436,'codec_full':481,'provider_new':9,'codec_new':3,'core_new':14,'core_full':core,'app_build':'0W/0E','native_host_build':'0W/0E','image_worker_build':'0W/0E','correct_locked_audited_restores':2},'scope':{'actual':'portable named pipe + original DesktopPipeChannel/Session/Inbox; actual Linux decoder/private Worker -> Browser encoded owner; actual linked shared Shell commands/coordinator and two-protocol loopback HTTP','synthetic':'verified peer/desktop confirmation and worker/prepared owner ports in managed tests; no real Windows/browser/WPF successful ingress; segmented tests, not full E2E','unchanged_old_tests':True},'source_hashes':source,'protected':{'count':len(protected),'all_equal':True,'catalog':'run/protected-hashes.json','provider_project_exception':'Compile link only; no ProjectReference/PackageReference changes'},'products':{'count':len(products),'catalog':'run/product-hashes.json'},'independent_review':'design + product source including final CancelAndJoin/permit/raw-token fixes ACK; no new definite P1/P2; review.txt records limited scope; reviewer did not test/build/write; Core failures remain open','failures_preserved':['r02 missing System.IO compile failure; import corrected','r04 CS0649 unused fixture fields; 0 executed','r10 injected pipe.Dispose failure leaves2034byte Inbox; actual failed assertion is Assert.Null(Inbox); pre-fix source preserved','r17/r20 MSB1009 nonexistent KuaiYi.Worker project path; product not compiled/audited; corrected r21/r22 succeeded','r13/r24 Core2069P1F; r23 targeted2P does not fix or explain it; root cause/relationship UNKNOWN; finally stack may mask body failure','old BMP historical469P1F then2P then470P remains UNKNOWN'], 'not_run':['Windows installed policy/held peer + Chrome/Edge/WPF complete flow','cold start/Explorer authenticated production handoff','cross-origin/auth/blob/visible-region fallback/additional browser formats','Windows OLE/COM/native OCR/installed identity','real source/password/integrity/quality/fonts','250/600ms and600MiB','full P6/P7/K group/Beta/106 acceptance'], 'constraints':['WebP odd payload explicitly rejected','PackageHold/production image reuse Off','no new dependency/license/permission/cost/credential/security network changes','synthetic neutral inputs only; no live models/private data/user desktop/CI/deployment/main/forcepush'],'archive':{'path':str(archive.relative_to(root)),'bytes':archive.stat().st_size,'sha256':sha(archive),'entries':len(entries)},'archive_members':entries}
(target/'2026-10-21-browser-image-preview.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'protected':len(protected),'source':len(source),'products':len(products),'archive':index['archive'],'core':core},ensure_ascii=False))
