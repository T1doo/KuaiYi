import subprocess,json,time,hashlib
from pathlib import Path
out=Path.cwd()/'artifacts/browser-image-preview'; rows=[]
args=['-c','Release','--no-restore','-nodeReuse:false','-p:UseSharedCompilation=false']
checks=[('r21-image-worker-build',['build','src/KuaiYi.ImageWorker/KuaiYi.ImageWorker.csproj',*args,'-p:EnableWindowsTargeting=true']),('r22-image-worker-locked-audit',['restore','src/KuaiYi.ImageWorker/KuaiYi.ImageWorker.csproj','--locked-mode','-p:EnableWindowsTargeting=true','-p:NuGetAudit=true','-p:NuGetAuditMode=all','-p:NuGetAuditLevel=low','-nodeReuse:false']),('r23-capture-host-failure-target',['test','tests/KuaiYi.Core.Tests/KuaiYi.Core.Tests.csproj',*args,'--no-build','--filter','FullyQualifiedName~CaptureHostTests.KillFailureOrUnconfirmedWaitRetainsOwnerAndBlocksFinalizeWithoutBlockingUi','--logger','trx;LogFileName=r23-capture-host-failure-target.trx','--results-directory',str(out)]),('r24-core-full-check',['test','tests/KuaiYi.Core.Tests/KuaiYi.Core.Tests.csproj',*args,'--no-build','--logger','trx;LogFileName=r24-core-full-check.trx','--results-directory',str(out)])]
for name,cmd in checks:
 command=['python3','-B','scripts/session-sdk.py',*cmd]; started=time.time()
 with (out/(name+'.log')).open('w') as f: code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
 rows.append(dict(name=name,command=command,exitCode=code,seconds=round(time.time()-started,3)))
 (out/'followup-checks.json').write_text(json.dumps(rows,indent=2)+'\n'); print(name,code,flush=True)
 if name=='r23-capture-host-failure-target' and code: break
