import json,subprocess,time
from pathlib import Path
root=Path.cwd(); out=root/'artifacts/browser-image-preview'; rows=[]
common=['-c','Release','--no-restore','-nodeReuse:false','-p:UseSharedCompilation=false']
checks=[('r13-core-full',['test','tests/KuaiYi.Core.Tests/KuaiYi.Core.Tests.csproj',*common,'--logger','trx;LogFileName=r13-core-full.trx','--results-directory',str(out)]),('r14-provider-full',['test','tests/KuaiYi.Provider.Tests/KuaiYi.Provider.Tests.csproj',*common,'--logger','trx;LogFileName=r14-provider-full.trx','--results-directory',str(out)]),('r15-codec-full',['test','tests/KuaiYi.Codec.Tests/KuaiYi.Codec.Tests.csproj',*common,'--logger','trx;LogFileName=r15-codec-full.trx','--results-directory',str(out)])]
for name,project in [('r16-app-build','src/KuaiYi.App/KuaiYi.App.csproj'),('r17-worker-build','src/KuaiYi.Worker/KuaiYi.Worker.csproj'),('r18-native-host-build','src/KuaiYi.NativeHost/KuaiYi.NativeHost.csproj')]:
 checks.append((name,['build',project,*common,'-p:EnableWindowsTargeting=true']))
for name,project in [('r19-app-locked-audit','src/KuaiYi.App/KuaiYi.App.csproj'),('r20-worker-locked-audit','src/KuaiYi.Worker/KuaiYi.Worker.csproj')]:
 checks.append((name,['restore',project,'--locked-mode','-p:EnableWindowsTargeting=true','-p:NuGetAudit=true','-p:NuGetAuditMode=all','-p:NuGetAuditLevel=low','-nodeReuse:false']))
for name,args in checks:
 command=['python3','-B','scripts/session-sdk.py',*args]; started=time.time()
 with (out/(name+'.log')).open('w') as f:
  code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
 rows.append(dict(name=name,command=command,exitCode=code,seconds=round(time.time()-started,3)))
 (out/'final-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name,code,flush=True)
