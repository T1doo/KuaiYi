using System;
using System.IO;
using System.Diagnostics;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using KuaiYi.SelectionReuseDiagnostic;
using KuaiYi.SelectionReusePrototype;

// Mechanism counterexample only. The original full-suite failure had no per-stage trace.
internal static class Probe
{
    static async Task<int> Main(string[] args)
    {
        var readEntered=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var releaseRead=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        await using var host=new ReuseDiagnosticHost(args[0],args[1],"crash",true,
            request:new DiagnosticRequest(new ReuseTarget(42,123456,99),1,2,3,4,true),matcher:_=>true);
        HeldOutput? held=null;
        typeof(ReuseDiagnosticHost).GetProperty("OutputForTest",BindingFlags.Instance|BindingFlags.NonPublic)!.SetValue(host,
            new Func<Stream,Stream>(inner=>held=new(inner,readEntered,releaseRead)));
        var watch=Stopwatch.StartNew();var run=host.RunAsync(2);
        try
        {
            await readEntered.Task.WaitAsync(TimeSpan.FromSeconds(3));
            var child=(Process)typeof(ReuseDiagnosticHost).GetField("child",BindingFlags.Instance|BindingFlags.NonPublic)!.GetValue(host)!;
            await child.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(3));
            Console.WriteLine($"PUBLIC_PROBE actualChildExit={child.ExitCode} originalReadHeld={!releaseRead.Task.IsCompleted} runCompleted={run.IsCompleted} elapsedMs={watch.Elapsed.TotalMilliseconds:F3}");
            if(child.ExitCode!=23||run.IsCompleted||watch.Elapsed>=TimeSpan.FromMilliseconds(600))throw new InvalidOperationException("Probe did not observe natural23 before the unchanged600ms boundary.");
            if(!held!.MarkedBuffer.Span.Contains((byte)0xa5))throw new InvalidOperationException("Original read buffer was not held.");
            await run.WaitAsync(TimeSpan.FromSeconds(3));
            if(host.Summary!=null||!host.HoldsOwnership||host.CanReplace||await host.TrySettleAsync())throw new InvalidOperationException("Unjoined read falsely settled.");
            Console.WriteLine("PUBLIC_PROBE deadlineObserved=true summaryAbsent=true originalReadUnjoined=true ownerRetained=true");
            releaseRead.TrySetResult();await held.Returned.Task.WaitAsync(TimeSpan.FromSeconds(3));
            var settle=Stopwatch.StartNew();while(!await host.TrySettleAsync()){if(settle.Elapsed>TimeSpan.FromSeconds(3))throw new TimeoutException();await Task.Yield();}
            var summary=host.Summary!;
            Console.WriteLine($"PUBLIC_PROBE reason={summary.Reason} termination={summary.Termination} exitConfirmed={summary.ExitConfirmed} buffersCleared={summary.BuffersCleared} ownerHeld={host.HoldsOwnership}");
            if(summary.Reason!=ReuseRoundReason.HardTimeout||summary.Termination!=WorkerTermination.NaturalNonZero||!summary.ExitConfirmed||!summary.BuffersCleared||host.HoldsOwnership||held.MarkedBuffer.Span.ContainsAnyExcept((byte)0))throw new InvalidOperationException("Counterexample did not reproduce or original buffer not erased.");
            Console.WriteLine("PUBLIC_PROBE sameOriginalInnerEofBeforeDeadline=true heldBufferMarkerErased=true budgetUnchangedMs=600");
            return 0;
        }
        finally{releaseRead.TrySetResult();await run.WaitAsync(TimeSpan.FromSeconds(3));}
    }
    private sealed class HeldOutput(Stream inner,TaskCompletionSource entered,TaskCompletionSource release):Stream
    {
        internal readonly TaskCompletionSource Returned=new(TaskCreationOptions.RunContinuationsAsynchronously);
        internal Memory<byte> MarkedBuffer;
        public override async ValueTask<int> ReadAsync(Memory<byte> buffer,CancellationToken cancellation=default)
        {
            int n=await inner.ReadAsync(buffer,CancellationToken.None);if(n!=0)throw new InvalidOperationException("Expected same original child EOF.");
            MarkedBuffer=buffer;buffer.Span.Fill(0xa5);entered.TrySetResult();
            try{await release.Task;return n;}finally{Returned.TrySetResult();}
        }
        public override bool CanRead=>true;public override bool CanSeek=>false;public override bool CanWrite=>false;public override long Length=>throw new NotSupportedException();public override long Position{get=>throw new NotSupportedException();set=>throw new NotSupportedException();}
        public override int Read(byte[] b,int o,int c)=>throw new NotSupportedException();public override void Flush()=>throw new NotSupportedException();public override long Seek(long o,SeekOrigin s)=>throw new NotSupportedException();public override void SetLength(long v)=>throw new NotSupportedException();public override void Write(byte[] b,int o,int c)=>throw new NotSupportedException();
    }
}
