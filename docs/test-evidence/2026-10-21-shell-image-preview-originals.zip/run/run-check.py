from pathlib import Path
import sys,subprocess,json,time,hashlib,xml.etree.ElementTree as E
out=Path('artifacts/p7-shell-image-preview');name=sys.argv[1];args=sys.argv[2:];cmd=['python3','-B','scripts/session-sdk.py',*args];log=out/(name+'.log');assert not log.exists()
start=time.monotonic()
with log.open('w') as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT).returncode
row={'command':cmd,'exitCode':code,'seconds':round(time.monotonic()-start,3),'log':str(log),'logSha256':hashlib.sha256(log.read_bytes()).hexdigest()}
trx=out/(name+'.trx')
if trx.exists():
 tree=E.parse(trx);ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};row['counts']=tree.find('.//t:Counters',ns).attrib;row['trxSha256']=hashlib.sha256(trx.read_bytes()).hexdigest();row['failures']=[dict(x.attrib,original=E.tostring(x,encoding='unicode')) for x in tree.findall('.//t:UnitTestResult',ns) if x.get('outcome')!='Passed']
(out/(name+'.json')).write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n');print(json.dumps(row,ensure_ascii=False,indent=2),flush=True);print(log.read_text()[-7000:],flush=True)
