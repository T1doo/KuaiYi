using System.Diagnostics;
using System.Runtime.InteropServices;
using KuaiYi.Contracts;
using KuaiYi.Core;
using KuaiYi.Core.Settings;
using KuaiYi.OleTransfer;
using Xunit;
namespace KuaiYi.Core.Tests;
public sealed class TextDropProcessTests
{
    private sealed class Starter(string mode):IOwnedProcessStarter
    {public Process? Child;public Process Start(ProcessStartInfo info){info.ArgumentList.Add(mode);return Child=SystemOwnedProcessStarter.Instance.Start(info);}}
    private sealed class Activation(Guid id):IOleActivationLease
    {public string Name=>OleReceiverWire.ActivationName(id);public bool Enabled,Disposed;public void Set(long epoch,bool enabled)=>Enabled=enabled;public void Dispose(){Assert.False(Enabled);Disposed=true;}}
    private sealed class Registrar:IOleTargetRegistrar
    {public bool IsSettledAndRevoked=>true;public Task RegisterAsync(long hwnd,byte[] bytes,CancellationToken token){Array.Clear(bytes);return Task.CompletedTask;}public ValueTask<bool> TryFinalizeAsync()=>ValueTask.FromResult(true);}
    private sealed class Destination:SynchronizationContext
    {private readonly System.Collections.Concurrent.ConcurrentQueue<Action> items=new();public readonly TaskCompletionSource Queued=new(TaskCreationOptions.RunContinuationsAsynchronously);public override void Post(SendOrPostCallback callback,object? state){items.Enqueue(()=>callback(state));Queued.TrySetResult();}public void Drain(){while(items.TryDequeue(out var next))next();}}
    private sealed class SilentClock:TimeProvider
    {public long Now;public override long TimestampFrequency=>1000;public override long GetTimestamp()=>Now;public override ITimer CreateTimer(TimerCallback cb,object? state,TimeSpan due,TimeSpan period)=>new Timer();private sealed class Timer:ITimer{public bool Change(TimeSpan due,TimeSpan period)=>true;public void Dispose(){}public ValueTask DisposeAsync()=>ValueTask.CompletedTask;}}
    private static string AssemblyPath()=>Path.GetFullPath(Path.Combine(AppContext.BaseDirectory,"../../../../../tools/KuaiYi.OleReceiverFixture/bin",new DirectoryInfo(AppContext.BaseDirectory).Parent!.Name,"net10.0/KuaiYi.OleReceiverFixture.dll"));
    [Theory][InlineData("formal")][InlineData("formal-duplicate-begin")][InlineData("formal-url")][InlineData("formal-source-swap")][InlineData("formal-point-swap")][InlineData("formal-missing-source")][InlineData("formal-missing-cleanup")][InlineData("formal-duplicate-payload")][InlineData("formal-move")][InlineData("formal-bad-utf8")]
    public async Task ProductionProtocolAndDropCoordinatorUseActualOwnedChildWithSyntheticOsBackend(string mode)
    {
        Guid id=Guid.NewGuid();var activation=new Activation(id);var starter=new Starter(mode);var gate=new RuntimeGate();gate.SetMode(TriggerMode.Drop);var endpoint=new EndpointOrigin(new Uri("https://public.invalid"));gate.ConsentTo(endpoint);Assert.True(gate.TryEnable(endpoint,true));var config=new SettingsSnapshot(new(),"public",SettingsLoadState.Current);var queue=new Destination();int accepted=0,failed=0;var target=new DropTargetGeometry(new(0,0,48,48),new(0,0,48,48),24);
        await using var capture=new DropCaptureCoordinator(gate,()=>config,s=>s==new SelectionWindow(123,456,789,"public.exe"),()=>true,999,queue,(_,_)=>accepted++,_=>failed++);var lease=capture.Open(id,gate.Snapshot.Epoch,target)!;var client=new OleReceiverClient(Environment.GetEnvironmentVariable("DOTNET_HOST_PATH")??"dotnet",new Registrar(),activation,AssemblyPath(),starter);var ready=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);byte[]? actual=null;
        var run=client.RunAsync(new(id,lease.WireEpoch,Environment.ProcessId,1,new byte[32],activation.Name,ProductionTextDrop:true),item=>{if(item.Phase=="Ready")ready.TrySetResult();else if(item.Phase=="QueryEnd"&&item.Effect==1)Assert.True(capture.Enter(lease,item.Transaction,item.Source!,item.Point!.Value,OleEffect.Copy));else if(item.Phase=="DropBegin"&&mode!="formal-duplicate-begin")Assert.True(capture.Begin(lease,item.Transaction,item.Source!,item.Point!.Value,OleEffect.Copy));else if(item.Phase=="DropBegin")capture.Begin(lease,item.Transaction,item.Source!,item.Point!.Value,OleEffect.Copy);},(epoch,txn,bytes,token)=>{Assert.True(MemoryMarshal.TryGetArray(bytes,out var segment));actual=segment.Array;return capture.ReceiveAsync(lease,txn,bytes,a=>client.TryApplyDrop(epoch,txn,a),token,()=>client.IsDropCurrent(epoch,txn));});
        try
        {
            await ready.Task.WaitAsync(TimeSpan.FromSeconds(4));Assert.False(activation.Enabled);Assert.True(await client.SetEnabledAsync(lease.WireEpoch,true,target,[]));
            if(mode is "formal" or "formal-duplicate-begin" or "formal-url"){await queue.Queued.Task.WaitAsync(TimeSpan.FromSeconds(4));queue.Drain();using var guard=new CancellationTokenSource(TimeSpan.FromSeconds(4));while(!client.DeliveryPublishedForTest||!client.DeliverySettlementForTest.IsCompleted)await Task.Delay(1,guard.Token);Assert.Equal(mode=="formal-url"?0:1,accepted);Assert.Equal(mode=="formal-url"?1:0,failed);Assert.All(actual!,b=>Assert.Equal(0,b));}
            else{Assert.NotNull(await Record.ExceptionAsync(()=>run.WaitAsync(TimeSpan.FromSeconds(4))));Assert.Equal(0,accepted);Assert.Null(actual);}
        }
        finally{client.Cancel();capture.Invalidate(true);queue.Drain();await Record.ExceptionAsync(()=>run.WaitAsync(TimeSpan.FromSeconds(4)));await client.DeliverySettlementForTest.WaitAsync(TimeSpan.FromSeconds(4));await client.RevocationSettlementForTest.WaitAsync(TimeSpan.FromSeconds(4));Assert.True(starter.Child!.HasExited);Assert.True(client.ObserveExit());Assert.True(await client.TryFinalizeAsync(true));await client.DisposeAsync();}
        if(mode=="formal")
        {
            Assert.Contains(OleTargetObservation.QueryWritten,client.TargetObservations);Assert.Contains(OleTargetObservation.QueryRead,client.TargetObservations);Assert.Contains(OleTargetObservation.QueryAccepted,client.TargetObservations);
            Assert.DoesNotContain(OleTargetObservation.CallbackEnter,client.TargetObservations); // Synthetic backend never proves native dispatch.
        }
    }
    [Theory][InlineData("off")][InlineData("mode")][InlineData("settings")][InlineData("source")][InlineData("deadline")]
    public async Task ActualWireDeliveryCannotCommitAfterQueuedIdentityExpires(string change)
    {
        Guid id=Guid.NewGuid();var activation=new Activation(id);var starter=new Starter("formal");var gate=new RuntimeGate();gate.SetMode(TriggerMode.Drop);var origin=new EndpointOrigin(new Uri("https://public.invalid"));gate.ConsentTo(origin);Assert.True(gate.TryEnable(origin,true));var settings=new SettingsSnapshot(new(),"public-v1",SettingsLoadState.Current);bool current=true;var queue=new Destination();var time=new SilentClock();int accepted=0;byte[]? actual=null;var target=new DropTargetGeometry(new(0,0,48,48),new(0,0,48,48),24);
        await using var capture=new DropCaptureCoordinator(gate,()=>settings,_=>current,()=>true,999,queue,(_,_)=>accepted++,_=>{},time);var lease=capture.Open(id,gate.Snapshot.Epoch,target)!;var client=new OleReceiverClient(Environment.GetEnvironmentVariable("DOTNET_HOST_PATH")??"dotnet",new Registrar(),activation,AssemblyPath(),starter,time);var ready=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var run=client.RunAsync(new(id,lease.WireEpoch,Environment.ProcessId,1,new byte[32],activation.Name,ProductionTextDrop:true),item=>{if(item.Phase=="Ready")ready.TrySetResult();else if(item.Phase=="QueryEnd")capture.Enter(lease,item.Transaction,item.Source!,item.Point!.Value,OleEffect.Copy);else if(item.Phase=="DropBegin")capture.Begin(lease,item.Transaction,item.Source!,item.Point!.Value,OleEffect.Copy);},(epoch,txn,bytes,token)=>{MemoryMarshal.TryGetArray(bytes,out var array);actual=array.Array;return capture.ReceiveAsync(lease,txn,bytes,a=>client.TryApplyDrop(epoch,txn,a),token,()=>client.IsDropCurrent(epoch,txn));});
        try{await ready.Task.WaitAsync(TimeSpan.FromSeconds(4));await client.SetEnabledAsync(lease.WireEpoch,true,target,[]);await queue.Queued.Task.WaitAsync(TimeSpan.FromSeconds(4));switch(change){case "off":gate.Disable();client.Cancel();capture.Invalidate();break;case "mode":gate.SetMode(TriggerMode.Selection);client.Cancel();capture.Invalidate();break;case "settings":settings=settings with{Version="public-v2"};capture.Invalidate();client.Cancel();break;case "source":current=false;break;default:time.Now=1500;break;}queue.Drain();using var guard=new CancellationTokenSource(TimeSpan.FromSeconds(4));while(!client.DeliveryPublishedForTest)await Task.Delay(1,guard.Token);await client.DeliverySettlementForTest.WaitAsync(TimeSpan.FromSeconds(4));Assert.Equal(0,accepted);Assert.All(actual!,b=>Assert.Equal(0,b));}
        finally{client.Cancel();capture.Invalidate(true);queue.Drain();await Record.ExceptionAsync(()=>run.WaitAsync(TimeSpan.FromSeconds(4)));await client.RevocationSettlementForTest.WaitAsync(TimeSpan.FromSeconds(4));Assert.True(await client.TryFinalizeAsync(true));await client.DisposeAsync();}
    }
    [Fact]public async Task HoverOnlyActualProtocolNeverInvokesTextDelivery()
    {Guid id=Guid.NewGuid();var activation=new Activation(id);var starter=new Starter("formal-hover-only");var client=new OleReceiverClient(Environment.GetEnvironmentVariable("DOTNET_HOST_PATH")??"dotnet",new Registrar(),activation,AssemblyPath(),starter);var ready=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);var hover=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);int reads=0;var run=client.RunAsync(new(id,1,Environment.ProcessId,1,new byte[32],activation.Name,ProductionTextDrop:true),e=>{if(e.Phase=="Ready")ready.TrySetResult();if(e.Phase=="QueryEnd")hover.TrySetResult();},(_,_,_,_)=>{reads++;return Task.CompletedTask;});try{await ready.Task.WaitAsync(TimeSpan.FromSeconds(4));await client.SetEnabledAsync(1,true,new(new(0,0,48,48),new(0,0,48,48),24),[]);await hover.Task.WaitAsync(TimeSpan.FromSeconds(4));Assert.Equal(0,reads);Assert.True(client.IsReady);}finally{client.Cancel();await Record.ExceptionAsync(()=>run.WaitAsync(TimeSpan.FromSeconds(4)));await client.RevocationSettlementForTest.WaitAsync(TimeSpan.FromSeconds(4));Assert.True(await client.TryFinalizeAsync(true));await client.DisposeAsync();}}
}
