using System.Text;
using System.Security.Cryptography;
using KuaiYi.Core;
using KuaiYi.Core.Settings;
using SettingsProfile=KuaiYi.Core.Settings.ApiProfile;

namespace KuaiYi.Providers;

public enum TextSubmission { Started, ConfirmationRequired, Reopened, Rejected }
public sealed record TextTranslationSnapshot(SelectionSourceSnapshot Source,SettingsSnapshot Settings,
    SettingsProfile Profile,RequestProfileBinding Binding,ApiProfile Transport,string Prompt,string TemplateVersion,int VersionNumber=1,bool IsRegeneration=false)
{public TranslationPreset Preset=>Settings.Data.Translation.Preset;public string? RegenerationTemplateVersion=>IsRegeneration?"regenerate@1":null;public string FullTemplateVersion=>TemplateVersion+(IsRegeneration?"+regenerate@1":"");}
public sealed record TextGenerationPreview(int VersionNumber,TranslationPreset Preset,string Model);
public sealed class TextTranslationOffer
{
    internal TextTranslationOffer(TextTranslationSnapshot snapshot,CaptureTicket ticket,bool regenerate,Guid session,int versionNumber,SettingsSnapshot? savedSettings=null)
    {Snapshot=snapshot with{VersionNumber=versionNumber};SavedSettings=savedSettings??snapshot.Settings;Ticket=ticket;Regenerate=regenerate;Session=session;}
    public TextTranslationSnapshot Snapshot{get;}
    internal SettingsSnapshot SavedSettings{get;}
    internal CaptureTicket Ticket{get;} internal bool Regenerate{get;} internal Guid Session{get;}
    internal RequestIdentity? Identity{get;set;} internal bool Launched{get;set;} internal bool Finished{get;set;}
    public bool RequiresConfirmation=>Snapshot.Source.SourceKind==SelectionSourceKind.OcrOnly||Snapshot.Source.Scalars>Snapshot.Settings.Data.Translation.AutoSoftLimitScalars;
}
public sealed record TextTranslationUpdate(RequestIdentity Identity,OverlayResultEvent Presentation,
    TextTranslationSnapshot Snapshot,string? Failure=null);

/// <summary>Prepare/submit/confirm/regenerate run on the destination thread. Transport runs off-thread;
/// every queued event and every actual HTTP attempt crosses the canonical gate. Memory only.</summary>
public sealed class TextTranslationCoordinator: IAsyncDisposable
{
    private readonly RuntimeGate gate;private readonly Func<SettingsSnapshot?> settings;
    private readonly Func<SelectionSourceSnapshot,bool,bool> sourceCurrent;
    private readonly Func<SelectionSourceSnapshot,bool> ocrSourceCurrent;
    private readonly ProviderClient provider;private readonly ProviderEventReceiver receiver;
    private readonly Func<RequestIdentity,TextTranslationSnapshot,CancellationToken,Task<SecretLease?>> openSecret;
    private readonly Action<TextTranslationUpdate> changed;private readonly DevelopmentTranslationBoundary? developmentBoundary;
    private readonly Func<SettingsProfile,ApiProfile>? transportFactory;
    private readonly Dictionary<Guid,TextTranslationSnapshot> snapshots=[];
    private readonly HashSet<Task> jobs=[];private readonly object jobsSync=new();
    private Guid? styleSession;private TranslationPreset? sessionStyle;
    private TextTranslationOffer? offered,submitted;private bool disposed;private Exception? deliveryFailure;
    private sealed record LiveRequest(RequestIdentity Identity,TextTranslationSnapshot Snapshot,SettingsSnapshot CompatibleSettings,bool SettingsRejected=false);
    private LiveRequest? liveRequest;
    private sealed class DestinationFailure(Exception inner):Exception("Translation destination failed.",inner);
    public OverlayResults Results{get;}
    public string? LastRejection{get;private set;}
    public Task Running{get;private set;}=Task.CompletedTask;
    public int RetainedSnapshotCount=>snapshots.Count;
    public TextTranslationCoordinator(RuntimeGate gate,Func<SettingsSnapshot?> settings,
        Func<SelectionSourceSnapshot,bool,bool> sourceCurrent,ProviderClient provider,SynchronizationContext destination,
        OverlayResults results,Action<TextTranslationUpdate> changed,
        Func<RequestIdentity,TextTranslationSnapshot,CancellationToken,Task<SecretLease?>>? openSecret=null,
        bool allowDevelopmentLoopback=false,DevelopmentTranslationBoundary? developmentBoundary=null,
        Func<SettingsProfile,ApiProfile>? transportFactory=null,Func<SelectionSourceSnapshot,bool>? ocrSourceCurrent=null)
    {
        this.gate=gate;this.settings=settings;this.sourceCurrent=sourceCurrent;this.provider=provider;
        receiver=new(gate,destination);Results=results;this.changed=changed;
        this.openSecret=openSecret??((_,_,_)=>throw new InvalidOperationException("Credential store unavailable."));
        this.developmentBoundary=developmentBoundary??(allowDevelopmentLoopback?DevelopmentTranslationBoundary.FromProfile(settings()?.Data.Profiles.FirstOrDefault(p=>p.Id==settings()?.Data.ActiveProfileId)??throw new ArgumentException("Initial test profile required.")):null);
        this.transportFactory=transportFactory;
        this.ocrSourceCurrent=ocrSourceCurrent??(_=>false);
    }
    public TextTranslationSnapshot? SelectedSnapshot=>Results.SelectedVersionId is {} id&&snapshots.TryGetValue(id,out var value)?value:null;
    public TextTranslationSnapshot? SnapshotForVersion(Guid versionId)=>snapshots.GetValueOrDefault(versionId);
    public TranslationPreset? SessionStyle=>SelectedSnapshot!=null&&SelectedSession==styleSession?sessionStyle:null;
    private Guid? SelectedSession=>Results.Versions.FirstOrDefault(v=>v.Identity.VersionId==Results.SelectedVersionId)?.Identity.SessionId; // All visible versions belong to the current retained source session; no body copy for preview.
    public TextGenerationPreview? NextGeneration=>SelectedSnapshot is {} snapshot&&SelectedSession is {} session?new(Results.NextVersionNumber(session),SessionStyle??snapshot.Preset,snapshot.Profile.Model):null;
    public bool SetSessionStyle(TranslationPreset? preset)
    {
        if(disposed||SelectedSession is not {} session||SelectedSnapshot==null||preset is {} value&&!Enum.IsDefined(value))return false;
        // A style edit changes the next generation only. A pending confirmation must be discarded;
        // an already launched request retains its immutable prompt/settings/version identity.
        if(offered is {Launched:false,Identity:{} pending})gate.StopRequest(pending);
        offered=null;styleSession=session;sessionStyle=preset;return true;
    }
    private static TextTranslationSnapshot RegenerationSnapshot(TextTranslationSnapshot snapshot,TranslationPreset? preset=null)
    {
        var frozen=snapshot.Settings;var chosen=preset??snapshot.Preset;
        if(chosen!=snapshot.Preset)frozen=frozen with{Data=frozen.Data with{Translation=frozen.Data.Translation with{Preset=chosen}}};
        var composition=PromptBuilder.Compose(frozen.Data.Translation,snapshot.Source.Text,true);return snapshot with{Settings=frozen,Prompt=composition.System,TemplateVersion=composition.TemplateVersion,IsRegeneration=true};
    }
    public bool IsOfferCurrent(TextTranslationOffer offer)=>!disposed&&ReferenceEquals(offered,offer);
    public TextTranslationOffer? Prepare(SelectionSourceSnapshot source)=>PrepareCore(source,false);
    public TextTranslationOffer? PrepareOcr(SelectionSourceSnapshot source,TranslationPreset preset)
        =>source.SourceKind==SelectionSourceKind.OcrOnly&&Enum.IsDefined(preset)?PrepareCore(source,false,preset):Reject("OCR_SOURCE_REQUIRED");
    private TextTranslationOffer? PrepareCore(SelectionSourceSnapshot source,bool explicitUse,TranslationPreset? preset=null,bool currentOcrSettings=false)
    {
        LastRejection=null;offered=null;
        if(disposed||settings() is not {} config||config.ReadOnly||config.RequiresRecovery||config.Version!=source.SettingsVersion&&!(currentOcrSettings&&explicitUse&&source.SourceKind==SelectionSourceKind.OcrOnly))return Reject("SETTINGS_CHANGED");
        if(!DevelopmentSettingsAllowed(config))return Reject("TEST_BOUNDARY_REJECTED");
        if(!ValidText(source,config.Data.Translation.HardLimitScalars))return Reject("SOURCE_INVALID_OR_TOO_LARGE");
        if(!SourceAllowed(source,config,explicitUse))return Reject("SOURCE_CHANGED_OR_EXCLUDED");
        var savedSettings=config; // A per-request OCR style changes the frozen prompt, not the committed baseline.
        if(preset is {} chosen)config=config with{Data=config.Data with{Translation=config.Data.Translation with{Preset=chosen}}};
        if(!gate.TryBeginPassiveCapture(gate.Snapshot.Mode,out var ticket))return Reject("ENABLE_REQUIRED");
        var profile=config.Data.Profiles.FirstOrDefault(p=>p.Id==config.Data.ActiveProfileId);
        if(profile==null||!gate.TryGetProfileBinding(profile.Id,out var binding))return Reject("PROFILE_REQUIRED");
        try
        {
            var transport=transportFactory?.Invoke(profile)??ProfileTransport(profile,developmentBoundary!=null,developmentBoundary);
            if(developmentBoundary!=null&&!developmentBoundary.Allows(transport))return Reject("TEST_BOUNDARY_REJECTED");
            var composition=PromptBuilder.Compose(config.Data.Translation,source.Text);
            var snapshot=new TextTranslationSnapshot(source,config,profile,binding,transport,
                composition.System,composition.TemplateVersion);
            var session=Same(snapshot,submitted?.Snapshot)?submitted!.Session:Guid.NewGuid();
            return offered=new(snapshot,ticket,false,session,Results.NextVersionNumber(session),savedSettings);
        }
        catch(Exception error)when(error is ArgumentException or SettingsValidationException){return Reject("PROFILE_INVALID");}
    }
    private TextTranslationOffer? Reject(string reason){LastRejection=reason;return null;}
    public TextTranslationOffer? PrepareRegeneration(bool useCurrentSettings=false)
    {
        LastRejection=null;offered=null;
        if(disposed||SelectedSnapshot is not {} snapshot)return Reject("NO_RETAINED_SOURCE");
        if(useCurrentSettings)
        {
            var current=snapshot.Source.SourceKind==SelectionSourceKind.OcrOnly?PrepareCore(snapshot.Source,true,currentOcrSettings:true):PrepareCore(snapshot.Source with{SettingsVersion=settings()?.Version??""},true);
            if(current==null)return null;
            var session=SelectedSession!.Value;return offered=new(RegenerationSnapshot(current.Snapshot),current.Ticket,true,session,Results.NextVersionNumber(session));
        }
        if(!gate.TryBeginPassiveCapture(gate.Snapshot.Mode,out var ticket)||!Eligible(snapshot,true))return Reject("REGENERATION_NOT_ELIGIBLE");
        var version=Results.Versions.First(v=>v.Identity.VersionId==Results.SelectedVersionId);
        return offered=new(RegenerationSnapshot(snapshot,SessionStyle),ticket,true,version.Identity.SessionId,Results.NextVersionNumber(version.Identity.SessionId));
    }
    public TextSubmission Submit(TextTranslationOffer offer,bool confirmed=false)
    {
        if(disposed||!ReferenceEquals(offered,offer)||offer.Launched)return TextSubmission.Rejected;
        var snapshot=offer.Snapshot;
        bool explicitUse=confirmed||offer.Regenerate;
        if(!Eligible(snapshot,explicitUse)||!offer.Regenerate&&settings()?.Version!=snapshot.Settings.Version)return TextSubmission.Rejected;
        if(offer.Identity is {} pending)
        {
            if(!gate.CanApply(pending))return TextSubmission.Rejected;
            if(!confirmed)return TextSubmission.ConfirmationRequired;
            Launch(offer,pending,true);return TextSubmission.Started;
        }
        if(!gate.IsCaptureCurrent(offer.Ticket))return TextSubmission.Rejected;
        if(!offer.Regenerate&&Same(snapshot,submitted?.Snapshot)&&
            (submitted is{Finished:false,Identity:{} existing}&&gate.CanApply(existing)||Results.HasText&&SelectedSnapshot is {} selected&&Same(snapshot,selected)))
        {Results.Reopen();return TextSubmission.Reopened;}
        if(!gate.TryStartProfileRequest(snapshot.Binding,offer.Session,Guid.NewGuid(),offer.Ticket,out var identity,out _))return TextSubmission.Rejected;
        // Cancelling the prior request can synchronously replace/clear this offer. Commit only
        // the still-winning command; StopRequest never cancels a newer request installed by it.
        if(!ReferenceEquals(offered,offer)||offer.Launched||!gate.CanApply(identity)||!Eligible(snapshot,explicitUse)||!offer.Regenerate&&settings()?.Version!=snapshot.Settings.Version)
        {gate.StopRequest(identity);return TextSubmission.Rejected;}
        offer.Identity=identity;submitted=offer;
        // A valid new source supersedes the previous request even while awaiting length confirmation.
        if(offer.RequiresConfirmation&&!confirmed)return TextSubmission.ConfirmationRequired;
        Launch(offer,identity,explicitUse);return TextSubmission.Started;
    }
    public void RejectConfirmation(TextTranslationOffer offer)
    {if(ReferenceEquals(offered,offer)&&!offer.Launched){if(offer.Identity is {} id)gate.StopRequest(id);offered=submitted=null;}}
    private void Launch(TextTranslationOffer offer,RequestIdentity identity,bool explicitUse)
    {
        offer.Launched=true;if(styleSession!=identity.SessionId){styleSession=null;sessionStyle=null;}snapshots[identity.VersionId]=offer.Snapshot;
        if(!Results.Begin(identity))return;
        Volatile.Write(ref liveRequest,new(identity,offer.Snapshot,offer.SavedSettings));
        PruneSnapshots();
        Publish(new(identity,new(OverlayResultEventKind.Begin),offer.Snapshot));
        Running=RunAsync(identity,offer.Snapshot,offer.Regenerate,explicitUse);
        lock(jobsSync)jobs.Add(Running);_=ObserveJob(Running);
    }
    private async Task ObserveJob(Task job)
    {try{await job.ConfigureAwait(false);}catch(Exception error){deliveryFailure=error;}finally{lock(jobsSync)jobs.Remove(job);}}
    private async Task RunAsync(RequestIdentity identity,TextTranslationSnapshot snapshot,bool regenerate,bool explicitUse)
    {
        await Task.Yield();
        if(!gate.TryLinkRequestCancellation(identity,CancellationToken.None,out var linked))return;
        using var lifetime=linked!;var budget=provider.FreezeBudget(snapshot.Transport);using var timeout=budget.Link(lifetime.Token);
        SecretLease? secret=null;bool terminal=false;
        bool SendEligible()=>Eligible(snapshot,explicitUse)&&(regenerate||LiveSettingsCompatible(identity,snapshot))&&gate.IsRequestProfileBindingCurrent(identity,snapshot.Binding);
        try
        {
            if(!SendEligible()||!gate.CanApply(identity)){terminal=await FailAsync(identity,snapshot,"SOURCE_OR_SETTINGS_CHANGED",lifetime.Token,budget,SendEligible).ConfigureAwait(false);return;}
            if(snapshot.Transport.Authentication!=Authentication.None)secret=await openSecret(identity,snapshot,timeout.Token).ConfigureAwait(false);
            await foreach(var envelope in provider.GenerateEnvelopesAsync(new(snapshot.Transport,snapshot.Prompt,snapshot.Source.Text),gate,identity,secret,timeout.Token,
                SendEligible,budget).ConfigureAwait(false))
            {
                bool rejected=false;
                bool received=await receiver.ReceiveAsync(envelope,value=>
                {
                    if(!SendEligible()||!gate.CanApply(identity)){rejected=true;Abandon(identity,snapshot);return;}
                    OverlayResultEvent? presentation=null;
                    if(value.Kind==ModelEventKind.TextDelta&&Results.Append(identity,value.Text!))presentation=new(OverlayResultEventKind.Delta,value.Text!);
                    else if(value.Kind==ModelEventKind.Usage&&value.Usage is {} usage&&Results.ObserveUsage(identity,usage.InputTokens,usage.OutputTokens))presentation=new(OverlayResultEventKind.Usage);
                    else if(value.Kind==ModelEventKind.Completed&&Results.Complete(identity)){presentation=new(OverlayResultEventKind.Complete);terminal=true;MarkFinished(identity);PruneSnapshots();}
                    else if(value.Kind==ModelEventKind.Failed&&Results.Fail(identity,timeout.IsCancellationRequested&&!lifetime.IsCancellationRequested?"REQUEST_TIMEOUT":value.Reason,timeout.IsCancellationRequested?null:value.RetryAfter)){presentation=new(OverlayResultEventKind.Stopped);terminal=true;MarkFinished(identity);PruneSnapshots();}
                    if(presentation!=null)Publish(new(identity,presentation,snapshot,value.Kind==ModelEventKind.Failed?timeout.IsCancellationRequested&&!lifetime.IsCancellationRequested?"REQUEST_TIMEOUT":value.Reason:null));
                },lifetime.Token,budget).ConfigureAwait(false);
                if(!received||terminal||rejected)break;
            }
            if(!terminal&&gate.CanApply(identity))terminal=await FailAsync(identity,snapshot,"REQUEST_NOT_COMPLETED",lifetime.Token,budget,SendEligible).ConfigureAwait(false);
        }
        catch(OperationCanceledException)when(lifetime.IsCancellationRequested){ /* Replaced/Off/lock/stop: gate rejects every late event. */ }
        catch(Exception error)when(error is not DestinationFailure)
        {
            string reason=error is OperationCanceledException?"REQUEST_TIMEOUT":error is System.Security.Cryptography.CryptographicException?"SECRET_UNAVAILABLE":"CLIENT_FAILURE";
            terminal=await FailAsync(identity,snapshot,reason,lifetime.Token,budget,SendEligible).ConfigureAwait(false);
        }
        finally{secret?.Dispose();if(!terminal){MarkFinished(identity);gate.StopRequest(identity);}}
    }
    private async Task<bool> FailAsync(RequestIdentity identity,TextTranslationSnapshot snapshot,string reason,CancellationToken cancellation,ProviderRequestBudget budget,Func<bool> eligible)
    {
        bool terminal=false;
        await receiver.ReceiveAsync(new(identity,new(ModelEventKind.Failed,Reason:reason)),value=>
        {if(!eligible()||!gate.CanApply(identity)){Abandon(identity,snapshot);return;}if(Results.Fail(identity,value.Reason)){terminal=true;MarkFinished(identity);PruneSnapshots();Publish(new(identity,new(OverlayResultEventKind.Stopped),snapshot,value.Reason));}},cancellation,budget).ConfigureAwait(false);
        return terminal; // Receiver delivery alone does not prove this version accepted a terminal event.
    }
    private void Abandon(RequestIdentity identity,TextTranslationSnapshot snapshot)
    {if(Results.Abandon(identity)){MarkFinished(identity);PruneSnapshots();Publish(new(identity,new(OverlayResultEventKind.Stopped),snapshot));}}
    private void Publish(TextTranslationUpdate update)
    {try{changed(update);}catch(Exception error){deliveryFailure=error;gate.StopRequest(update.Identity);throw new DestinationFailure(error);}}
    private void MarkFinished(RequestIdentity identity)
    {
        gate.MarkRequestTerminal(identity);if(submitted?.Identity==identity)submitted.Finished=true;
        // A concurrent compatible-save validator can replace this same owner's cache entry.
        // Clear that owner completely, without clearing any newer request.
        while(Volatile.Read(ref liveRequest) is {} live&&live.Identity==identity)
            if(ReferenceEquals(Interlocked.CompareExchange(ref liveRequest,null,live),live))break;
    }
    private bool Eligible(TextTranslationSnapshot snapshot,bool explicitUse)
    {
        var current=settings();if(disposed||current==null||current.ReadOnly||current.RequiresRecovery||
            !DevelopmentSettingsAllowed(current)||developmentBoundary!=null&&(!developmentBoundary.Allows(snapshot.Profile)||!developmentBoundary.Allows(snapshot.Transport))||
            !gate.TryGetProfileBinding(snapshot.Profile.Id,out var binding)||binding!=snapshot.Binding||
            !gate.HasConsentTo(new(snapshot.Transport.ResolveEndpoint())))return false;
        if(snapshot.Source.SourceKind==SelectionSourceKind.Clipboard&&!ClipboardApplicationConsent.Allowed(snapshot.Source.Window.Executable,current.Data.Privacy))return false;
        return SourceAllowed(snapshot.Source,current,explicitUse);
    }
    private bool SourceAllowed(SelectionSourceSnapshot source,SettingsSnapshot config,bool explicitUse)
    {
        if(source.SourceKind==SelectionSourceKind.OcrOnly)
            return source.Ocr is {SourceVersion:var version,SourceId:var id,PreviewId:var preview}&&version!=Guid.Empty&&id!=Guid.Empty&&preview!=Guid.Empty&&
                source.Window==new SelectionWindow(0,0,0,"")&&source.Ranges.IsEmpty&&source.RuntimeId.IsEmpty&&source.DropReceiver==Guid.Empty&&source.DropTransaction==Guid.Empty&&
                source.Recovery==ClipboardRecovery.NotNeeded&&source.RequiresConfirmation&&ocrSourceCurrent(source);
        return Enum.IsDefined(source.SourceKind)&&source.Ocr==null&&!SelectionTextPolicy.Excluded(source.Window,config.Data,(uint)Environment.ProcessId)&&sourceCurrent(source,explicitUse);
    }
    private bool DevelopmentSettingsAllowed(SettingsSnapshot current)
    {
        bool allowed=developmentBoundary==null||!current.ReadOnly&&!current.RequiresRecovery&&current.Data.Profiles.FirstOrDefault(p=>p.Id==current.Data.ActiveProfileId) is {} profile&&developmentBoundary.Allows(profile);
        if(!allowed)gate.Disable();return allowed;
    }
    public void ObserveSettings(SettingsSnapshot current)
    {
        DevelopmentSettingsAllowed(current);var live=Volatile.Read(ref liveRequest);if(live==null)return;
        var profile=current.Data.Profiles.FirstOrDefault(p=>p.Id==live.Snapshot.Profile.Id);
        if(current.Data.ActiveProfileId!=live.Snapshot.Profile.Id||profile==null||!ApiProfilePolicy.RequestEquivalent(profile,live.Snapshot.Profile))gate.StopRequest(live.Identity);
        else if(!live.Snapshot.IsRegeneration&&current.Version!=live.CompatibleSettings.Version&&!AdvanceDisplaySettings(live,current))
        {
            // Keep this identity long enough for its next destination event to run the original Abandon/fallback.
            // The permanent denial also rejects send admission and cannot be undone by restoring saved fields.
            while(Volatile.Read(ref liveRequest) is {} owner&&owner.Identity==live.Identity&&!owner.SettingsRejected)
                if(ReferenceEquals(Interlocked.CompareExchange(ref liveRequest,owner with{SettingsRejected=true},owner),owner))break;
        }
    }
    private bool LiveSettingsCompatible(RequestIdentity identity,TextTranslationSnapshot snapshot)
    {
        while(true)
        {
            var live=Volatile.Read(ref liveRequest);if(live?.Identity!=identity||live.SettingsRejected)return false;
            var current=settings();if(current==null)return false;if(current.Version==snapshot.Settings.Version)return true;
            // A committed snapshot can become visible just before its notification. Validate that same narrow transition here.
            if(current.Version==live.CompatibleSettings.Version||AdvanceDisplaySettings(live,current))return true;
            if(settings()?.Version==current.Version)return false; // Re-evaluate a commit which overtook this check.
        }
    }
    private bool AdvanceDisplaySettings(LiveRequest live,SettingsSnapshot current)
    {
        if(live.SettingsRejected||current.ReadOnly||current.RequiresRecovery||current.Data.WriteId==Guid.Empty||current.Data.WriteId==live.CompatibleSettings.Data.WriteId||settings()?.Version!=current.Version)return false;
        byte[]? before=null,after=null;
        try
        {
            // Compare every persisted field, normalizing only presentation and the coordinator's transaction marker.
            // This runs only at a changed snapshot; per-token checks use the already accepted immutable version.
            before=SettingsJson.Write(live.CompatibleSettings.Data);
            after=SettingsJson.Write(current.Data with{Overlay=live.CompatibleSettings.Data.Overlay,WriteId=live.CompatibleSettings.Data.WriteId});
            if(!before.AsSpan().SequenceEqual(after))return false;
            var observed=Interlocked.CompareExchange(ref liveRequest,live with{CompatibleSettings=current},live);
            return ReferenceEquals(observed,live)||observed?.Identity==live.Identity&&!observed.SettingsRejected&&ReferenceEquals(observed.Snapshot,live.Snapshot)&&observed.CompatibleSettings.Version==current.Version;
        }
        catch(SettingsValidationException){return false;}
        finally{if(before!=null)CryptographicOperations.ZeroMemory(before);if(after!=null)CryptographicOperations.ZeroMemory(after);}
    }
    public bool CanUseSettings(SettingsSnapshot current)=>DevelopmentSettingsAllowed(current);
    private void PruneSnapshots()
    {var retained=Results.RetainedVersionIds;foreach(var id in snapshots.Keys.Where(id=>!retained.Contains(id)).ToArray())snapshots.Remove(id);}
    public void Clear(){styleSession=null;sessionStyle=null;Volatile.Write(ref liveRequest,null);if(submitted?.Identity is {} id)gate.StopRequest(id);offered=submitted=null;snapshots.Clear();Results.Clear();}
    public Task ClearAsync()
    {
        Clear();Task[] pending;lock(jobsSync)pending=jobs.ToArray();
        return Task.WhenAll(pending); // Only jobs owned at this clear; a later valid generation is independent.
    }
    public async ValueTask DisposeAsync()
    {
        disposed=true;if(submitted?.Identity is {} id)gate.StopRequest(id);offered=submitted=null;
        Task[] pending;lock(jobsSync)pending=jobs.ToArray();await Task.WhenAll(pending).ConfigureAwait(false);
        snapshots.Clear();if(deliveryFailure!=null)throw new InvalidOperationException("Translation destination delivery failed.",deliveryFailure);
    }
    private static bool Same(TextTranslationSnapshot a,TextTranslationSnapshot? b)=>b!=null&&a.Profile with{Headers=b.Profile.Headers}==b.Profile&&a.Profile.Headers.OrderBy(p=>p.Key).SequenceEqual(b.Profile.Headers.OrderBy(p=>p.Key))&&a.Binding==b.Binding&&
        PromptTemplatePolicy.Equivalent(a.Settings.Data.Translation,b.Settings.Data.Translation)&&a.Source.Window==b.Source.Window&&a.Source.Text==b.Source.Text&&a.Source.SourceKind==b.Source.SourceKind&&
        a.Source.RuntimeId.SequenceEqual(b.Source.RuntimeId)&&a.Source.Ranges.SequenceEqual(b.Source.Ranges)&&a.Source.DropReceiver==b.Source.DropReceiver&&ReferenceEquals(a.Source.Ocr,b.Source.Ocr);
    private static bool ValidText(SelectionSourceSnapshot source,int hardLimit)
    {
        if(string.IsNullOrWhiteSpace(source.Text)||source.Text.Length>=100002||source.RuntimeId.IsDefault||source.Ranges.IsDefault)return false;
        int scalars=0;for(int i=0;i<source.Text.Length;i++,scalars++){char c=source.Text[i];if(char.IsHighSurrogate(c)){if(++i>=source.Text.Length||!char.IsLowSurrogate(source.Text[i]))return false;}else if(char.IsLowSurrogate(c))return false;}
        return scalars==source.Scalars&&scalars<=hardLimit&&scalars<=50000;
    }
    public static ApiProfile ProfileTransport(SettingsProfile profile,bool allowDevelopmentLoopback=false,DevelopmentTranslationBoundary? developmentBoundary=null)
    {
        var boundary=developmentBoundary??(allowDevelopmentLoopback?DevelopmentTranslationBoundary.FromProfile(profile):null);
        try{return ApiProfileMapper.Plan(profile,boundary).Transport;}catch(SettingsValidationException error){throw new ArgumentException("Invalid profile: "+error.Field,error);}
    }
}
